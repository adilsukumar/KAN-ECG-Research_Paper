"""Verify final evidence and recompute pooled outcomes from predictions."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix,f1_score,matthews_corrcoef,roc_auc_score,average_precision_score,brier_score_loss
HERE=Path(__file__).resolve().parent; ROOT=HERE/'kaggle_download/remaining_clean'
hashes=json.loads((ROOT/'artifact_hashes.json').read_text())
for name,expected in hashes.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
frozen=json.loads((ROOT/'frozen_pipeline.json').read_text())
assert frozen['frozen_before_locked_test'] and frozen['selection_data']=='DS1 training and validation only'
seed=pd.read_csv(ROOT/'kan_seed_validation.csv'); assert sorted(seed.seed.tolist())==[11,23,42,57,89]
best=seed.sort_values(['ventricular_f1','mcc','parameters','seed'],ascending=[False,False,True,True]).iloc[0]
assert int(best.seed)==frozen['teacher']['seed']
search=pd.read_csv(ROOT/'symbolic_validation_search.csv')
eligible=(search.fidelity_r2>=.90)&(search.decision_agreement>=.95)&(search.sensitivity>=.90)&(search.complexity<=25)&(search.sensitivity_loss<=.03)
assert np.array_equal(eligible.to_numpy(),search.qualifies.to_numpy())
assert (frozen['symbolic'] is not None)==bool(eligible.any())
cohort=json.loads((ROOT/'incart_cohort.json').read_text()); assert cohort['records']==75 and cohort['patients']==32
assert len(cohort['raw_hashes'])==225
assert json.loads((ROOT/'progress.json').read_text())['stage']=='PHASES_3_4_5_COMPLETE'
def calc(y,s,t):
    p=s>=t; tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
    return dict(ventricular_f1=f1_score(y,p,zero_division=0),sensitivity=tp/max(tp+fn,1),
        specificity=tn/max(tn+fp,1),precision=tp/max(tp+fp,1),mcc=matthews_corrcoef(y,p),
        auroc=roc_auc_score(y,s),auprc=average_precision_score(y,s),brier=brier_score_loss(y,s),
        tn=tn,fp=fp,fn=fn,tp=tp)
tables={}; sensitivity=[]
for name in ['ds2','incart']:
    df=pd.read_csv(ROOT/(name+'_predictions.csv')); table=pd.read_csv(ROOT/(name+'_metrics.csv')); tables[name]=table
    assert not df[['record_id','label']].isna().any().any()
    assert df.record_id.nunique()==(22 if name=='ds2' else 75)
    if name=='incart': assert df.cluster_id.nunique()==32 and len(df)==cohort['beats']
    for _,row in table.iterrows():
        score=df[row.family+'_score'].to_numpy(); y=df.label.to_numpy(); assert np.isfinite(score).all()
        assert np.array_equal((score>=row.threshold).astype(int),df[row.family+'_prediction'].to_numpy())
        for key,value in calc(y,score,row.threshold).items(): assert np.isclose(row[key],value,atol=1e-8),(name,row.family,key)
        if name=='ds2':
            keep=df.record_id.astype(str).ne('202').to_numpy()
            sensitivity.append(dict(family=row.family,excluded_record='202',reason='shares source analog tape with training record 201',n=int(keep.sum()),**calc(y[keep],score[keep],row.threshold)))
    ci=pd.read_csv(ROOT/(name+'_clustered_bootstrap_ci.csv')); assert (ci.bootstrap_replicates==2000).all()
    assert (ci.ci_lower<=ci.ci_upper).all()
    if name=='incart': assert set(ci.cluster_unit)=={'patient'}
pd.DataFrame(sensitivity).to_csv(HERE/'ds2_excluding_record202_sensitivity.csv',index=False)
audit=dict(status='PASS',hash_verified_artifacts=len(hashes),all_pooled_metrics_recomputed=True,
    external_records=75,external_patients=32,symbolic_qualifies=frozen['symbolic'] is not None,
    protocol_sha256=frozen['protocol_sha256'],
    limitation='DS2 is record-disjoint; 201/202 share source tape. Excluding 202 is a descriptive frozen-model sensitivity analysis.')
(HERE/'remaining_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
text='# Phases 3 to 5 final audit\n\nStatus: PASS\n\n'
text+=f"Verified {len(hashes)} SHA-256 artifacts. Recomputed every pooled metric from saved labels, scores and frozen thresholds. Five prescribed seeds and validation teacher selection match the freeze manifest. Symbolic gates were preserved. INCART includes all 75 records and 32 source patients with 2,000 patient-clustered bootstrap replicates.\n\n"
for name,table in tables.items():
    text+='## '+name.upper()+' outcomes\n\n'+table[['family','ventricular_f1','sensitivity','specificity','precision','mcc','auprc','brier']].to_csv(index=False)+'\n'
text+='## Internal patient overlap limitation\n\nPhysioNet documents record 202 as originating from the same analog tape as record 201. The frozen conventional split places 201 in training and 202 in DS2. Therefore internal evidence is record-disjoint, not strictly patient-disjoint. A descriptive sensitivity analysis excludes record 202 using unchanged model weights and thresholds. External evaluation remains independent. Source: https://physionet.org/physiobank/database/html/mitdbdir/records.htm#202\n'
(HERE/'PHASES_3_4_5_AUDIT.md').write_text(text,encoding='utf-8')
print(json.dumps(audit,indent=2))
