"""Clean Phase 3–5 pipeline; markers become Kaggle cells."""
# %% Inputs and specification
from pathlib import Path
import copy, hashlib, json, os, platform, random, re, sys, time, zipfile
import numpy as np
import pandas as pd
import torch
from torch import nn
import joblib
import matplotlib.pyplot as plt
from scipy.special import expit, logit
from sklearn.metrics import confusion_matrix, f1_score, matthews_corrcoef, roc_auc_score, average_precision_score, brier_score_loss, r2_score, roc_curve, precision_recall_curve
from sklearn.calibration import calibration_curve
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import OrthogonalMatchingPursuit
WORK=Path('/kaggle/working') if Path('/kaggle/working').exists() else Path.cwd()
OUT=WORK/'remaining_clean'; FIG=OUT/'figures'; MODELS=OUT/'models'
for p in (OUT,FIG,MODELS): p.mkdir(parents=True,exist_ok=True)
DEVICE=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.set_num_threads(min(4,os.cpu_count() or 2)); SEEDS=[11,23,42,57,89]
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,default=str),encoding='utf-8')
def checkpoint(stage):
    save('progress.json',dict(stage=stage,utc=pd.Timestamp.now(tz='UTC').isoformat()))
    print('CHECKPOINT:',stage,flush=True)
def locate(filename,marker):
    root=Path('/kaggle/input') if Path('/kaggle/input').exists() else Path.cwd().parent.parent
    found={p.parent.resolve() for p in root.rglob(filename) if (p.parent/marker).exists()}
    if len(found)!=1: raise RuntimeError(f'Missing or ambiguous {filename}: {found}')
    return found.pop()
PHASE1=locate('train_arrays.npz','phase1_summary.json')
PHASE2=locate('selected_models.json','metrics_point_estimates.csv')
PROTOCOL=json.loads((PHASE1/'study_protocol.json').read_text())
PROTOCOL_HASH=digest(PHASE1/'study_protocol.json')
assert PROTOCOL_HASH==json.loads((PHASE1/'phase1_summary.json').read_text())['protocol_sha256']
for root,files in [(PHASE1,['train_arrays.npz','validation_arrays.npz']),(PHASE2,['selected_models.json'])]:
    hashes=json.loads((root/'artifact_hashes.json').read_text())
    for name in files: assert digest(root/name)==hashes[name],name
train=np.load(PHASE1/'train_arrays.npz'); val=np.load(PHASE1/'validation_arrays.npz')
Xtr,ytr=train['X'].astype('float32'),train['y'].astype(int)
Xv,yv=val['X'].astype('float32'),val['y'].astype(int)
FEATURES=train['feature_names'].astype(str).tolist()
assert set(train['record_id'].astype(str)).isdisjoint(val['record_id'].astype(str))
assert np.isfinite(Xtr).all() and np.isfinite(Xv).all()
save('experiment_specification.json',dict(protocol_sha256=PROTOCOL_HASH,seeds=SEEDS,
    architecture='12-hidden-1 degree-one spline edge KAN with SiLU residual',
    grid='uniform [-4,4]; clipped standardized inputs; hidden inputs 4*tanh(h/4)',
    configurations=[[8,8],[16,8],[8,16],[16,16]],epochs=120,patience=18,batch=1024,
    optimizer='AdamW lr .003 weight decay .0001',
    selection='validation constrained F1 then MCC then parameter count then lower seed',
    symbolic='OMP sparse polynomial dictionary degree 1 or 2 to teacher training logits',
    sparsities=[1,2,3,4,5,6,8],complexity='expression nodes including clip and sigmoid',
    test_selection=False,external='75 INCART records, patient bootstrap, no fitting or recalibration'))
checkpoint('inputs_audited_specification_saved')

# %% Metrics and spline KAN
def metrics(y,s,t):
    p=s>=t; tn,fp,fn,tp=confusion_matrix(y,p,labels=[0,1]).ravel()
    return dict(ventricular_f1=float(f1_score(y,p,zero_division=0)),sensitivity=float(tp/max(tp+fn,1)),
        specificity=float(tn/max(tn+fp,1)),precision=float(tp/max(tp+fp,1)),
        macro_f1=float(f1_score(y,p,average='macro',zero_division=0)),mcc=float(matthews_corrcoef(y,p)),
        auroc=float(roc_auc_score(y,s)) if len(np.unique(y))==2 else np.nan,
        auprc=float(average_precision_score(y,s)) if len(np.unique(y))==2 else np.nan,
        brier=float(brier_score_loss(y,s)),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp))
def threshold(y,s):
    ix=np.argsort(-s,kind='stable'); a=y[ix]; b=s[ix]; tp=np.cumsum(a); fp=np.cumsum(1-a)
    f=2*tp/np.maximum(tp+fp+y.sum(),1)
    pool=np.flatnonzero(np.r_[b[1:]!=b[:-1],True] & (tp/y.sum()>=.90))
    assert len(pool)
    return float(b[pool[np.argmax(f[pool])]])
def rank(r): return (r['ventricular_f1'],r['mcc'],-r['parameters'],-r['seed'])
class SplineLayer(nn.Module):
    def __init__(self,i,o,g):
        super().__init__(); self.register_buffer('knots',torch.linspace(-4,4,g+1)); self.delta=8/g
        self.coeff=nn.Parameter(torch.randn(o,i,g+1)*.025)
        self.base=nn.Parameter(torch.randn(o,i)/np.sqrt(i)); self.bias=nn.Parameter(torch.zeros(o))
    def forward(self,x):
        z=x.clamp(-4,4); b=(1-(z[:,:,None]-self.knots).abs()/self.delta).clamp_min(0)
        return nn.functional.linear(b.flatten(1),self.coeff.flatten(1))+nn.functional.linear(nn.functional.silu(z),self.base,self.bias)
class SplineKAN(nn.Module):
    def __init__(self,h,g):
        super().__init__(); self.first=SplineLayer(12,h,g); self.second=SplineLayer(h,1,g)
    def forward(self,x): return self.second(4*torch.tanh(self.first(x)/4)).flatten()
def predict(model,x):
    model.eval(); device=next(model.parameters()).device
    with torch.no_grad():
        return np.concatenate([torch.sigmoid(model(torch.as_tensor(b,device=device,dtype=torch.float32))).cpu().numpy()
            for b in np.array_split(x,max(1,int(np.ceil(len(x)/4096))))])
def fit(h,g,seed):
    name=f'kan_h{h}_g{g}_s{seed}'
    cached=MODELS/(name+'.pt')
    if cached.exists():
        saved=torch.load(cached,map_location=DEVICE,weights_only=False)
        model=SplineKAN(h,g).to(DEVICE); model.load_state_dict(saved['state_dict'])
        print('RESUMED',name,flush=True)
        return model,saved['selection']
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    model=SplineKAN(h,g).to(DEVICE); opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.0001)
    loss_fn=nn.BCEWithLogitsLoss(pos_weight=torch.tensor((len(ytr)-ytr.sum())/ytr.sum(),device=DEVICE))
    tx=torch.as_tensor(Xtr,device=DEVICE); ty=torch.as_tensor(ytr,device=DEVICE,dtype=torch.float32)
    best=(-1.,-1.); state=None; stale=0; history=[]; start=time.perf_counter()
    for epoch in range(120):
        model.train(); losses=[]
        for ids in torch.randperm(len(tx),device=DEVICE).split(1024):
            opt.zero_grad(); loss=loss_fn(model(tx[ids]),ty[ids])+1e-5*(model.first.coeff.abs().mean()+model.second.coeff.abs().mean())
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5); opt.step(); losses.append(loss.item())
        sv=predict(model,Xv); th=threshold(yv,sv); m=metrics(yv,sv,th)
        history.append(dict(epoch=epoch+1,loss=float(np.mean(losses)),**m)); key=(m['ventricular_f1'],m['mcc'])
        if key>best: best=key; state=copy.deepcopy(model.state_dict()); best_epoch=epoch+1; stale=0
        else: stale+=1
        if stale>=18: break
    model.load_state_dict(state); sv=predict(model,Xv); th=threshold(yv,sv)
    row=dict(hidden=h,intervals=g,seed=seed,epochs=len(history),best_epoch=best_epoch,
        parameters=sum(p.numel() for p in model.parameters()),threshold=th,training_seconds=time.perf_counter()-start,**metrics(yv,sv,th))
    torch.save(dict(state_dict={k:v.cpu() for k,v in state.items()},selection=row),MODELS/(name+'.pt'))
    pd.DataFrame(history).to_csv(OUT/(name+'_history.csv'),index=False)
    print('TRAINED',name,'validation F1',round(row['ventricular_f1'],4),flush=True)
    return model,row

# %% Validation configuration and five seeds
rows=[]; cache={}
for h,g in [(8,8),(16,8),(8,16),(16,16)]:
    model,row=fit(h,g,11); rows.append(row); cache[h,g,11]=model
pd.DataFrame(rows).to_csv(OUT/'kan_configuration_selection.csv',index=False)
config=max(rows,key=rank); h,g=config['hidden'],config['intervals']; seeds=[config]
for seed in SEEDS[1:]:
    model,row=fit(h,g,seed); seeds.append(row); cache[h,g,seed]=model
pd.DataFrame(seeds).to_csv(OUT/'kan_seed_validation.csv',index=False)
teacher_row=max(seeds,key=rank); teacher=cache[h,g,teacher_row['seed']]; teacher_threshold=teacher_row['threshold']
teacher_train=predict(teacher,Xtr); teacher_val=predict(teacher,Xv)
checkpoint('phase3_five_seed_KAN_training_complete')

# %% Constrained symbolic regression
sr_rows=[]; candidates=[]
for degree in (1,2):
    poly=PolynomialFeatures(degree,include_bias=False); atr=poly.fit_transform(np.clip(Xtr,-4,4)); av=poly.transform(np.clip(Xv,-4,4))
    for terms in (1,2,3,4,5,6,8):
        reg=OrthogonalMatchingPursuit(n_nonzero_coefs=terms); reg.fit(atr,logit(np.clip(teacher_train,1e-5,1-1e-5)))
        sv=expit(reg.predict(av)); th=threshold(yv,sv); m=metrics(yv,sv,th); active=np.flatnonzero(abs(reg.coef_)>1e-12)
        complexity=2
        for j in active:
            p=poly.powers_[j]; n=int(np.count_nonzero(p)); complexity+=3+3*n+2*int(np.sum(p>1))+max(n-1,0)
        fidelity=float(r2_score(teacher_val,sv)); agreement=float(np.mean((sv>=th)==(teacher_val>=teacher_threshold)))
        loss=teacher_row['sensitivity']-m['sensitivity']
        qualifies=fidelity>=.90 and agreement>=.95 and m['sensitivity']>=.90 and complexity<=25 and loss<=.03
        row=dict(degree=degree,terms=len(active),complexity=complexity,threshold=th,fidelity_r2=fidelity,
            decision_agreement=agreement,sensitivity_loss=loss,qualifies=bool(qualifies),**m)
        sr_rows.append(row); candidates.append((poly,reg,row))
pd.DataFrame(sr_rows).to_csv(OUT/'symbolic_validation_search.csv',index=False)
eligible=[c for c in candidates if c[2]['qualifies']]
symbolic=max(eligible,key=lambda c:(c[2]['ventricular_f1'],-c[2]['complexity'])) if eligible else None
if symbolic:
    poly,reg,row=symbolic; joblib.dump(dict(poly=poly,reg=reg,selection=row),MODELS/'symbolic.joblib')
    formula='sigmoid('+str(float(reg.intercept_))+''.join(f' + ({float(reg.coef_[j]):.12g})*'+poly.get_feature_names_out([f'clip(z{i+1},-4,4)' for i in range(12)])[j] for j in np.flatnonzero(abs(reg.coef_)>1e-12))+')'
    save('symbolic_expression.json',dict(formula=formula,standardized_features=FEATURES,selection=row))
else: save('symbolic_expression.json',dict(status='no_qualifying_symbolic_surrogate',scope='constrained polynomial dictionary and budget; not impossibility',gates='unchanged'))
checkpoint('phase3_symbolic_search_complete')

# %% Phase 4 validation diagnostics and freeze
rng=np.random.default_rng(20260930); importance=[]; masking=[]
for j,name in enumerate(FEATURES):
    drops=[]
    for repeat in range(10):
        x=Xv.copy(); x[:,j]=rng.permutation(x[:,j]); drops.append(teacher_row['ventricular_f1']-metrics(yv,predict(teacher,x),teacher_threshold)['ventricular_f1'])
    importance.append(dict(feature=name,mean_f1_drop=float(np.mean(drops)),sd_f1_drop=float(np.std(drops))))
    x=Xv.copy(); x[:,j]=0; masking.append(dict(feature=name,**metrics(yv,predict(teacher,x),teacher_threshold)))
pd.DataFrame(importance).to_csv(OUT/'phase4_permutation_importance.csv',index=False)
pd.DataFrame(masking).to_csv(OUT/'phase4_feature_masking.csv',index=False)
noise=[]
for sd in (0.,.05,.10,.20): noise.append(dict(standardized_feature_noise_sd=sd,**metrics(yv,predict(teacher,Xv+rng.normal(0,sd,Xv.shape).astype('float32')),teacher_threshold)))
pd.DataFrame(noise).to_csv(OUT/'phase4_feature_noise.csv',index=False)
imp=pd.DataFrame(importance).sort_values('mean_f1_drop'); fig,ax=plt.subplots(figsize=(8,5)); ax.barh(imp.feature,imp.mean_f1_drop,xerr=imp.sd_f1_drop)
ax.set(xlabel='Validation V-F1 decrease after permutation',title='KAN feature dependence'); fig.tight_layout(); fig.savefig(FIG/'phase4_importance.png',dpi=300); plt.close(fig)
cpu=copy.deepcopy(teacher).cpu(); timings=[]
with torch.no_grad():
    for batch in (1,256,4096):
        a=torch.as_tensor(Xv[:batch])
        for _ in range(10): cpu(a)
        for _ in range(30):
            start=time.perf_counter(); cpu(a); timings.append(dict(batch=batch,seconds=time.perf_counter()-start))
pd.DataFrame(timings).to_csv(OUT/'phase4_cpu_latency.csv',index=False)
save('frozen_pipeline.json',dict(protocol_sha256=PROTOCOL_HASH,teacher=teacher_row,symbolic=symbolic[2] if symbolic else None,
    selection_data='DS1 training and validation only',frozen_before_locked_test=True,
    masking='mean feature masking without retraining',noise='feature perturbation, not clinical signal noise',cpu_threads=torch.get_num_threads()))
checkpoint('phase4_complete_pipeline_frozen')

# %% Locked internal test and shared clustered inference
test=np.load(PHASE1/'locked_test_arrays.npz'); Xt,yt=test['X'].astype('float32'),test['y'].astype(int)
assert set(test['record_id'].astype(str)).isdisjoint(train['record_id'].astype(str))
assert set(test['record_id'].astype(str)).isdisjoint(val['record_id'].astype(str))
selected=json.loads((PHASE2/'selected_models.json').read_text()); baselines={}
for family in selected:
    paths=list((PHASE2/'models').glob(f'*{family}*')); assert len(paths)==1,(family,paths)
    assert digest(paths[0])==json.loads((PHASE2/'artifact_hashes.json').read_text())[str(paths[0].relative_to(PHASE2))]
    baselines[family]=joblib.load(paths[0])
def all_scores(x):
    scores={'kan':(predict(teacher,x),teacher_threshold)}
    for family,model in baselines.items(): scores[family]=(model.predict_proba(x)[:,1],selected[family]['threshold'])
    if symbolic:
        poly,reg,row=symbolic; scores['symbolic']=(expit(reg.predict(poly.transform(np.clip(x,-4,4)))),row['threshold'])
    return scores
def evaluate(name,x,y,records,clusters):
    scores=all_scores(x); rows=[]; predictions=pd.DataFrame(dict(record_id=records,cluster_id=clusters,label=y))
    for family,(s,t) in scores.items():
        rows.append(dict(cohort=name,family=family,threshold=t,**metrics(y,s,t))); predictions[family+'_score']=s; predictions[family+'_prediction']=(s>=t).astype(int)
    pd.DataFrame(rows).to_csv(OUT/(name+'_metrics.csv'),index=False); predictions.to_csv(OUT/(name+'_predictions.csv'),index=False)
    groups=np.unique(clusters); ids=[np.flatnonzero(clusters==c) for c in groups]; lookup=np.searchsorted(groups,clusters)
    counts=np.random.default_rng(20261928).multinomial(len(groups),np.ones(len(groups))/len(groups),size=2000)
    ci=[]; boots={}
    for family,(s,t) in scores.items():
        p=s>=t; cc=np.array([[np.sum((y[ix]==0)&~p[ix]),np.sum((y[ix]==0)&p[ix]),np.sum((y[ix]==1)&~p[ix]),np.sum((y[ix]==1)&p[ix])] for ix in ids],dtype=float)
        tn,fp,fn,tp=(counts@cc).T
        vals=dict(ventricular_f1=2*tp/np.maximum(2*tp+fp+fn,1),sensitivity=tp/np.maximum(tp+fn,1),specificity=tn/np.maximum(tn+fp,1),
            precision=tp/np.maximum(tp+fp,1),mcc=(tp*tn-fp*fn)/np.maximum(np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)),1))
        # Pre-sort once: exact weighted AUROC/AP avoid sorting each bootstrap replicate.
        order=np.argsort(-s,kind='stable'); sy=y[order]; sl=lookup[order]; ss=s[order]; boundaries=np.flatnonzero(np.r_[ss[1:]!=ss[:-1],True])
        auc=[]; ap=[]; bs=[]
        for c in counts:
            w=c[sl]; ctp=np.cumsum(w*sy)[boundaries]; cfp=np.cumsum(w*(1-sy))[boundaries]; pos=ctp[-1]; neg=cfp[-1]
            if pos and neg:
                auc.append(np.trapezoid(np.r_[0,ctp/pos],np.r_[0,cfp/neg])); ap.append(np.sum(np.diff(np.r_[0,ctp/pos])*ctp/np.maximum(ctp+cfp,1)))
            else: auc.append(np.nan); ap.append(np.nan)
            bs.append(np.average((s-y)**2,weights=c[lookup]))
        vals.update(auroc=np.array(auc),auprc=np.array(ap),brier=np.array(bs)); boots[family]=vals
        point=metrics(y,s,t)
        for metric,a in vals.items(): ci.append(dict(family=family,metric=metric,estimate=point[metric],ci_lower=float(np.nanpercentile(a,2.5)),ci_upper=float(np.nanpercentile(a,97.5)),bootstrap_replicates=2000,cluster_unit='patient' if name=='incart' else 'record'))
        print('BOOTSTRAP',name,family,'complete',flush=True)
    pd.DataFrame(ci).to_csv(OUT/(name+'_clustered_bootstrap_ci.csv'),index=False)
    paired=[]
    for family in scores:
        if family=='kan': continue
        for metric in ('ventricular_f1','sensitivity','mcc','auprc'):
            d=boots['kan'][metric]-boots[family][metric]; paired.append(dict(model_a='kan',model_b=family,metric=metric,point_delta=rows[0][metric]-next(r[metric] for r in rows if r['family']==family),ci_lower=float(np.nanpercentile(d,2.5)),ci_upper=float(np.nanpercentile(d,97.5))))
    pd.DataFrame(paired).to_csv(OUT/(name+'_paired_comparisons.csv'),index=False)
    per=[]
    for rec in np.unique(records):
        ix=records==rec
        for family,(s,t) in scores.items(): per.append(dict(record_id=rec,family=family,n=int(ix.sum()),n_positive=int(y[ix].sum()),**metrics(y[ix],s[ix],t)))
    pd.DataFrame(per).to_csv(OUT/(name+'_per_record_metrics.csv'),index=False)
    fig,axes=plt.subplots(1,2,figsize=(10,4))
    for family,(s,t) in scores.items():
        fpr,tpr,_=roc_curve(y,s); pp,rr,_=precision_recall_curve(y,s); axes[0].plot(fpr,tpr,label=family); axes[1].plot(rr,pp,label=family)
    axes[0].set(xlabel='False-positive rate',ylabel='Sensitivity',title=name.upper()+' ROC'); axes[1].set(xlabel='Recall',ylabel='Precision',title=name.upper()+' precision recall')
    for ax in axes: ax.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(FIG/(name+'_roc_pr.png'),dpi=300); plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(9,4))
    for family,(s,t) in scores.items():
        obs,mean=calibration_curve(y,s,n_bins=10,strategy='quantile'); axes[0].plot(mean,obs,marker='.',label=family)
    axes[0].plot([0,1],[0,1],'k--'); axes[0].set(xlabel='Predicted probability',ylabel='Observed V fraction',title='Calibration'); axes[0].legend(fontsize=6)
    cm=confusion_matrix(y,scores['kan'][0]>=teacher_threshold); axes[1].imshow(cm,cmap='Blues')
    for i in range(2):
        for j in range(2): axes[1].text(j,i,str(cm[i,j]),ha='center',va='center')
    axes[1].set(xticks=[0,1],yticks=[0,1],xticklabels=['nonV','V'],yticklabels=['nonV','V'],xlabel='Prediction',ylabel='Reference',title='KAN confusion matrix')
    fig.tight_layout(); fig.savefig(FIG/(name+'_calibration_confusion.png'),dpi=300); plt.close(fig)
    return rows
seed_test=[]
for row in seeds: seed_test.append(dict(seed=row['seed'],threshold=row['threshold'],**metrics(yt,predict(cache[h,g,row['seed']],Xt),row['threshold'])))
pd.DataFrame(seed_test).to_csv(OUT/'kan_seed_locked_test.csv',index=False)
evaluate('ds2',Xt,yt,test['record_id'].astype(str),test['record_id'].astype(str))
checkpoint('phase3_internal_test_complete')

# %% Phase 5 exact source features and external cohort
import subprocess
subprocess.check_call([sys.executable,'-m','pip','install','-q','wfdb==4.3.0'])
import wfdb
from scipy.signal import butter,sosfiltfilt,resample
import requests
from concurrent.futures import ThreadPoolExecutor,as_completed
RAW=WORK/'incart_raw'; RAW.mkdir(exist_ok=True)
POSITIVE=set(PROTOCOL['positive_symbols']); ELIGIBLE=POSITIVE|set(PROTOCOL['negative_symbols'])
exec(PHASE1_FEATURE_SOURCE)
base='https://physionet.org/files/incartdb/1.0.0/'
def fetch(name):
    for suffix in ('hea','atr','dat'):
        p=RAW/(name+'.'+suffix)
        if p.exists() and p.stat().st_size: continue
        for attempt in range(5):
            try:
                r=requests.get(base+p.name,timeout=(30,120)); r.raise_for_status(); p.write_bytes(r.content); break
            except requests.RequestException:
                if attempt==4: raise
                time.sleep(2*(attempt+1))
    return name
names=[f'I{i:02d}' for i in range(1,76)]
with ThreadPoolExecutor(max_workers=4) as pool:
    for future in as_completed([pool.submit(fetch,n) for n in names]): print('INCART downloaded',future.result(),flush=True)
external=[]; audits=[]
for name in names:
    rows,waves,audit=process_record(name,'external'); comments=' '.join(wfdb.rdheader(str(RAW/name)).comments)
    match=re.search(r'patient\s*(?:number|no\.?|#)?\s*[:=]?\s*(\d+)',comments,re.I)
    if not match: raise RuntimeError('Unverified patient grouping '+name+': '+comments)
    for row in rows: row.update(database='incartdb',patient_id=match.group(1))
    external.extend(rows); audits.append(dict(**audit,patient_id=match.group(1)))
    print('INCART extracted',name,len(rows),flush=True)
df=pd.DataFrame(external); df.to_csv(OUT/'incart_features_unscaled.csv',index=False); pd.DataFrame(audits).to_csv(OUT/'incart_record_audit.csv',index=False)
assert len(audits)==75 and df.patient_id.nunique()==32
imputer=joblib.load(PHASE1/'feature_imputer.joblib'); scaler=joblib.load(PHASE1/'feature_scaler.joblib')
Xe=scaler.transform(imputer.transform(df[FEATURES])).astype('float32'); ye=df.label.to_numpy().astype(int); assert np.isfinite(Xe).all()
save('incart_cohort.json',dict(records=75,patients=int(df.patient_id.nunique()),beats=len(df),ventricular_beats=int(ye.sum()),
    positive_prevalence=float(ye.mean()),missingness=df[FEATURES].isna().mean().to_dict(),no_external_fitting=True,
    raw_hashes={p.name:digest(p) for p in RAW.iterdir() if p.is_file()}))
checkpoint('phase5_external_preprocessing_complete')
evaluate('incart',Xe,ye,df.record_id.to_numpy(),df.patient_id.to_numpy())
save('environment_manifest.json',dict(protocol_sha256=PROTOCOL_HASH,python=sys.version,torch=torch.__version__,numpy=np.__version__,pandas=pd.__version__,platform=platform.platform(),gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None))
checkpoint('PHASES_3_4_5_COMPLETE')
save('artifact_hashes.json',{str(p.relative_to(OUT)):digest(p) for p in OUT.rglob('*') if p.is_file() and p.name!='artifact_hashes.json'})
with zipfile.ZipFile(WORK/'remaining_clean_artifacts.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file(): z.write(p,str(Path('remaining_clean')/p.relative_to(OUT)))
print('ALL_EXPERIMENTS_COMPLETE',flush=True)
