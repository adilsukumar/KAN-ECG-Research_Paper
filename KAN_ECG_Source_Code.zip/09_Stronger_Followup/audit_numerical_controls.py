"""Independent score, metric, gate and provenance audit; no refitting."""
import sys, json, hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent
if sys.version_info[:2]==(3,11): sys.path.insert(0,str(HERE/'runtime'))
import numpy as np
import pandas as pd
from scipy.special import expit
OUT=HERE/'control_outputs'; ROOT=HERE.parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((OUT/'input_hashes.json').read_text()); outputs=json.loads((OUT/'output_hashes.json').read_text())
for rel,digest in inputs.items(): assert sha(ROOT/rel)==digest,rel
for rel,digest in outputs.items(): assert sha(OUT/rel)==digest,rel
val=np.load(ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean/validation_arrays.npz',allow_pickle=False); x=np.clip(val['X'],-4,4).astype(float); y=val['y']; truth=y==1
thresholds=pd.read_csv(HERE/'pilot_outputs/teacher_validation.csv').set_index('teacher').threshold.to_dict()
rows=pd.read_csv(OUT/'normalized_candidates.csv'); assert len(rows)==168 and rows.candidate_id.nunique()==168
maxerr=0; maximum_metric_difference=0
for row in rows.to_dict('records'):
    e=json.loads((OUT/'expressions'/f"{row['candidate_id']}.json").read_text()); raw=np.full(len(x),e['intercept'])
    for term in e['terms']: raw+=term['coefficient']*np.prod(x**np.asarray(term['powers']),axis=1)
    s=expit(raw) if e['link']=='sigmoid' else np.clip(raw,0,1)
    archive=np.load(OUT/'expressions'/f"{row['candidate_id']}.npz",allow_pickle=False); err=float(abs(s-archive['validation_probability']).max()); maxerr=max(maxerr,err); assert err<1e-12
    p=np.load(HERE/f"pilot_outputs/{row['teacher']}_teacher_scores.npz",allow_pickle=False)['validation']; pred=s>=e['threshold']; teacher_pred=p>=thresholds[row['teacher']]
    assert np.array_equal(pred,archive['validation_prediction'])
    tp=int((pred&truth).sum()); fp=int((pred&~truth).sum()); fn=int((~pred&truth).sum())
    expected=dict(fidelity_r2=1-float(((p-s)**2).sum()/((p-p.mean())**2).sum()),probability_rmse=float(np.sqrt(np.mean((p-s)**2))),decision_agreement=float(np.mean(pred==teacher_pred)),sensitivity=tp/truth.sum(),sensitivity_loss=((teacher_pred&truth).sum()-tp)/truth.sum(),ventricular_f1=2*tp/max(2*tp+fp+fn,1),tp=tp,fp=fp,fn=fn)
    for k,v in expected.items():
        delta=float(abs(v-row[k])); maximum_metric_difference=max(maximum_metric_difference,delta)
        assert delta<1e-6,(row['candidate_id'],k,delta)
    size=2 if e['link']=='sigmoid' else 3
    for term in e['terms']:
        power=np.array(term['powers']); n=np.count_nonzero(power); size+=3+3*n+2*np.sum(power>1)+max(n-1,0)
    assert size==row['complexity']
    gates=dict(fidelity=expected['fidelity_r2']>=.9,agreement=expected['decision_agreement']>=.95,sensitivity=expected['sensitivity']>=.9,complexity=size<=25,sensitivity_loss=expected['sensitivity_loss']<=.03)
    assert all(bool(row['gate_'+k])==bool(v) for k,v in gates.items()); assert bool(row['qualifies'])==all(gates.values())
    ix=np.argsort(-s,kind='stable'); a=y[ix]; b=s[ix]; tp_seq=np.cumsum(a); fp_seq=np.cumsum(1-a)
    pool=np.flatnonzero(np.r_[b[1:]!=b[:-1],True] & (tp_seq/y.sum()>=.9)); f1=2*tp_seq/np.maximum(tp_seq+fp_seq+y.sum(),1)
    assert e['threshold']==float(b[pool[np.argmax(f1[pool])]])
controls=pd.read_csv(OUT/'positive_controls.csv'); assert len(controls)==24
for row in controls.to_dict('records'):
    rng=np.random.default_rng(row['seed']); z=rng.uniform(-1,1,(6000,12))[4000:]
    scale=1 if row['link']=='sigmoid' else .1; intercept=.2 if row['link']=='sigmoid' else .5
    raw=intercept+scale*(.7*z[:,0]-.4*z[:,3] if row['degree']==1 else .7*z[:,0]**2-.4*z[:,3]+.3*z[:,5])
    ref=expit(raw) if row['link']=='sigmoid' else np.clip(raw,0,1)
    archive=np.load(OUT/f"control_s{row['seed']}_d{row['degree']}_{row['link']}_n{int(row['normalized'])}.npz",allow_pickle=False); s=archive['validation_probability']
    rmse=float(np.sqrt(np.mean((s-ref)**2))); r2=1-float(((s-ref)**2).sum()/((ref-ref.mean())**2).sum())
    assert rmse<=1e-6 and r2>=.999999 and abs(r2-row['fidelity_r2'])<1e-12
report=dict(status='PASS',inputs_verified=len(inputs),output_hashes_verified=len(outputs),positive_controls_recomputed=24,candidates_recomputed=168,maximum_expression_roundtrip_error=maxerr,maximum_metric_difference=maximum_metric_difference,metric_tolerance=1e-6,metric_precision_note='Float32 cached teacher variance versus independent NumPy reduction',external_evaluation=False)
(OUT/'independent_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(report))
