"""Independent expression, score, split, transformation and source-label audit."""
import sys,json,hashlib
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
import numpy as np,pandas as pd,joblib,torch,wfdb
from scipy.special import expit
ROOT=HERE.parent; P1=ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x): p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding='utf-8')
def score(e,x,family):
    z=np.clip(x,-4,4).astype(float)
    if family=='additive':
        columns=[z[:,j] for j in range(12)]
        for j,values in enumerate(e['knots']): columns.extend(np.maximum(z[:,j]-v,0) for v in values)
        return np.clip(np.array(columns).T@np.array(e['coefficient'])+e['intercept'],0,1)
    for index,layer in enumerate(e['layers']):
        c=np.array(layer['polynomial']); raw=np.tile(np.array(layer['bias']),(len(z),1))
        for power in range(c.shape[2]): raw+=(z**power)@c[:,:,power].T
        raw+=(z*expit(z))@np.array(layer['base']).T
        z=4*np.tanh(raw/4) if index==0 else raw
    return expit(z[:,0])
def metric(y,s,t,teacher=None,teacher_t=None):
    pred=s>=t; pos=y==1; tp=int((pred&pos).sum()); fp=int((pred&~pos).sum()); fn=int((~pred&pos).sum()); tn=int((~pred&~pos).sum())
    r=dict(ventricular_f1=2*tp/max(2*tp+fp+fn,1),sensitivity=tp/max(tp+fn,1),precision=tp/max(tp+fp,1),specificity=tn/max(tn+fp,1),tp=tp,fp=fp,fn=fn,tn=tn)
    if teacher is not None:
        r.update(fidelity_r2=1-float(((teacher-s)**2).sum()/((teacher-teacher.mean())**2).sum()),probability_rmse=float(np.sqrt(np.mean((teacher-s)**2))),decision_agreement=float(np.mean(pred==(teacher>=teacher_t))),sensitivity_loss=float(((teacher>=teacher_t)&pos).sum()/pos.sum()-r['sensitivity']))
    return r
def compare(expected,row):
    for key,value in expected.items():
        if key in row: assert abs(float(value)-float(row[key]))<1e-6,(key,value,row[key])
def hashes(folder):
    files=json.loads((folder/'output_hashes.json').read_text())
    for rel,h in files.items(): assert sha(folder/rel)==h,rel
    return len(files)
tr=np.load(P1/'train_arrays.npz',allow_pickle=False); va=np.load(P1/'validation_arrays.npz',allow_pickle=False); xv=va['X']; yv=va['y']; xt=tr['X']
folder=HERE/'broader_outputs'; n=hashes(folder)
for rel,h in json.loads((folder/'input_hashes.json').read_text()).items(): assert sha(ROOT/rel)==h,rel
thresholds=pd.read_csv(HERE/'pilot_outputs/teacher_validation.csv').set_index('teacher').threshold.to_dict(); rows=pd.read_csv(folder/'surrogate_validation.csv'); assert len(rows)==21
for row in rows.to_dict('records'):
    e=json.loads((folder/'models'/f"{row['candidate_id']}.json").read_text()); s=score(e,xv,row['family']); ar=np.load(folder/'models'/f"{row['candidate_id']}_validation.npz",allow_pickle=False)
    assert np.max(abs(s-ar['probability']))<1e-10; assert np.array_equal(s>=row['threshold'],ar['prediction'])
    teacher=np.load(HERE/f"pilot_outputs/{row['teacher']}_teacher_scores.npz",allow_pickle=False)['validation']; expected=metric(yv,s,row['threshold'],teacher,thresholds[row['teacher']]); compare(expected,row)
    size=3+12*6+sum(len(k) for k in e['knots'])*10 if row['family']=='additive' else 208*(3*e['degree']+12)+34+191+64+2
    assert row['complexity']==size
    gates=dict(fidelity=expected['fidelity_r2']>=.9,agreement=expected['decision_agreement']>=.95,sensitivity=expected['sensitivity']>=.9,sensitivity_loss=expected['sensitivity_loss']<=.03,complexity=size<=25)
    assert all(bool(row['gate_'+k])==bool(v) for k,v in gates.items()) and bool(row['qualifies'])==all(gates.values())
stability=np.load(folder/'stability_predictions.npz',allow_pickle=False); st=pd.read_csv(folder/'stability_replicates.csv'); assert len(st)==30
target=np.load(HERE/'pilot_outputs/kan_teacher_scores.npz',allow_pickle=False)['train'].astype(float); groups=tr['record_id'].astype(str); unique=np.unique(groups); rng=np.random.default_rng(20261004); expressions=[]
for b in range(30):
    counts=np.bincount(rng.integers(0,len(unique),len(unique)),minlength=len(unique)); w=np.array([counts[np.searchsorted(unique,g)] for g in groups],dtype=float)
    coef=stability['polynomial_coefficient'][b]; intercept=float(np.average(target,weights=w)-np.average(np.clip(xt,-4,4).astype(float),axis=0,weights=w)@coef)
    s=np.clip(np.clip(xv,-4,4).astype(float)@coef+intercept,0,1); assert np.max(abs(s-stability['polynomial'][b]))<1e-10
    e=json.loads((folder/'models'/f'bootstrap_additive_{b:02}.json').read_text()); q=score(e,xv,'additive'); assert np.max(abs(q-stability['additive'][b]))<1e-10
    expressions.append(dict(replicate=b,intercept=intercept,coefficient=coef.tolist(),threshold=float(st.iloc[b].polynomial_threshold),complexity=21,link='clip_probability'))
save(folder/'audited_polynomial_bootstrap_expressions.json',expressions)
benchmark=HERE/'grouped_benchmark'; bn=hashes(benchmark); assert json.loads((benchmark/'summary.json').read_text())['status']=='COMPLETE'
for rel,h in json.loads((benchmark/'input_hashes.json').read_text()).items(): assert sha(ROOT/rel)==h,rel
raw=pd.read_csv(P1/'beat_features_unscaled.csv',dtype={'record_id':str}); names=tr['feature_names'].astype(str).tolist(); original_x=raw[names].to_numpy(); labels=raw.label.to_numpy()
for split in range(3):
    members=pd.read_csv(benchmark/f'split{split}_membership.csv',dtype={'record_id':str,'source_group':str})
    assert np.array_equal(members.record_id,raw.record_id) and np.array_equal(members.annotation_sample,raw.annotation_sample)
    assert np.array_equal(members.source_group,raw.record_id.replace({'202':'201'}))
    sets=[set(members.loc[members.partition==p,'source_group']) for p in ('train','validation','test')]; assert not (sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])
    train=np.flatnonzero(members.partition=='train'); transformer=joblib.load(benchmark/'models'/f'split{split}_transforms.joblib'); med=np.nanmedian(original_x[train],axis=0)
    assert np.max(abs(transformer['imputer'].statistics_-med))<1e-10
    imputed=np.where(np.isnan(original_x[train]),med,original_x[train]); assert np.max(abs(transformer['scaler'].mean_-imputed.mean(axis=0)))<1e-10
    assert np.max(abs(transformer['scaler'].scale_-imputed.std(axis=0)))<1e-10
    arrays=np.load(benchmark/f'split{split}_feature_arrays.npz',allow_pickle=False)
    for key in ('train','validation','test'):
        ids=np.flatnonzero(members.partition==key); assert np.array_equal(ids,arrays[key+'_ids'])
        transformed=transformer['scaler'].transform(transformer['imputer'].transform(original_x[ids])).astype('float32'); assert np.array_equal(transformed,arrays[key+'_X'])
for row in pd.read_csv(benchmark/'configuration_validation.csv').to_dict('records'):
    a=np.load(benchmark/'models'/f"{row['candidate_id']}_validation.npz",allow_pickle=False); compare(metric(a['label'],a['score'],row['threshold']),row)
preds=pd.read_csv(benchmark/'test_predictions.csv',dtype={'record_id':str,'source_group':str}); testmetrics=pd.read_csv(benchmark/'selected_test_metrics.csv'); configurations=pd.read_csv(benchmark/'configuration_validation.csv')
for row in testmetrics.to_dict('records'):
    g=preds[(preds.split==row['split'])&(preds.family==row['family'])]; compare(metric(g.label.to_numpy(),g.score.to_numpy(),row['threshold']),row)
    selected=configurations[(configurations.split==row['split'])&(configurations.family==row['family'])].sort_values(['ventricular_f1','configuration'],ascending=[False,True]).iloc[0]; assert selected.candidate_id==row['candidate_id']
report=dict(status='PASS',broader_hashes=n,surrogate_candidates=21,bootstrap_expression_recomputations=60,benchmark_hashes=bn,source_disjoint_splits=3,configuration_metrics=18,test_metrics=9)
sv=HERE/'svdb_holdout'
if (sv/'summary.json').exists():
    sn=hashes(sv); frozen=json.loads((sv/'frozen_before_download.json').read_text())
    for rel,h in frozen['input_sha256'].items(): assert sha(ROOT/rel)==h,rel
    df=pd.read_csv(sv/'features_unscaled.csv',dtype={'record_id':str}); predictions=pd.read_csv(sv/'predictions.csv',dtype={'record_id':str}); arrays=np.load(sv/'evaluation_arrays.npz',allow_pickle=False)
    assert np.array_equal(df.record_id,predictions.record_id) and np.array_equal(df.annotation_sample,predictions.annotation_sample)
    assert np.array_equal(df.record_id,arrays['record_id']) and np.array_equal(df.label,arrays['y'])
    imputer=joblib.load(P1/'feature_imputer.joblib'); scaler=joblib.load(P1/'feature_scaler.joblib'); assert np.array_equal(scaler.transform(imputer.transform(df[names])).astype('float32'),arrays['X'])
    protocol=json.loads((P1/'study_protocol.json').read_text()); positive=set(protocol['positive_symbols']); eligible=positive|set(protocol['negative_symbols']); records=(sv/'raw/RECORDS').read_text().split(); assert len(records)==78
    for record in records:
        ann=wfdb.rdann(str(sv/'raw'/record),'atr'); lookup=set(zip(ann.sample,ann.symbol)); g=df[df.record_id==record]
        # Rhythm/event annotations can share a beat sample; a dict would discard one.
        for row in g.itertuples(): assert (row.annotation_sample,row.annotation_symbol) in lookup and row.annotation_symbol in eligible and row.label==int(row.annotation_symbol in positive)
    for row in pd.read_csv(sv/'metrics.csv').to_dict('records'):
        name=row['model']; s=predictions[name+'_score'].to_numpy(); expected=metric(df.label.to_numpy(),s,frozen['thresholds'][name]); compare(expected,row)
        if name in ('additive','edgewise','polynomial'):
            teacher=predictions['kan_score'].to_numpy(); m=metric(df.label.to_numpy(),s,frozen['thresholds'][name],teacher,frozen['thresholds']['kan'])
            assert abs(m['fidelity_r2']-row['teacher_probability_r2'])<1e-6 and abs(m['decision_agreement']-row['decision_agreement'])<1e-6
    archive=np.load(sv/'bootstrap_replicates.npz',allow_pickle=False); values={}
    for name in frozen['thresholds']:
        if name+'_score' not in predictions: continue
        counts=np.array([[metric(df.loc[df.record_id==record,'label'].to_numpy(),predictions.loc[df.record_id==record,name+'_score'].to_numpy(),frozen['thresholds'][name])[k] for k in ('tp','fp','fn')] for record in records]); total=archive['weights']@counts
        v=2*total[:,0]/np.maximum(2*total[:,0]+total[:,1]+total[:,2],1); assert np.max(abs(v-archive[name]))<1e-10; values[name]=v
    difference=values['kan']-values['random_forest']; paired=json.loads((sv/'paired_comparison.json').read_text()); assert abs(np.quantile(difference,.025)-paired['low'])<1e-10 and abs(np.quantile(difference,.975)-paired['high'])<1e-10
    report.update(svdb_hashes=sn,svdb_records=78,svdb_beats=len(df),annotation_alignment_verified=True,svdb_metrics=6,paired_bootstrap_recomputed=True,patient_independence_verified=False)
save(HERE/'broad_extension_audit.json',report); print(json.dumps(report,indent=2))
