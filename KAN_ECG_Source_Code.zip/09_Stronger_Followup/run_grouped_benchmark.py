"""Three exploratory source-group-separated comparisons; never external tuning."""
import os,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'): os.environ[k]='4'
import numpy as np,pandas as pd,torch,joblib,json,hashlib,time,copy,warnings
from torch import nn
from sklearn.model_selection import GroupShuffleSplit
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from run_distillation_pilot import Layer,threshold
ROOT=HERE.parent; P1=ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'
OUT=HERE/'grouped_benchmark'; OUT.mkdir(exist_ok=True); (OUT/'models').mkdir(exist_ok=True)
START=time.monotonic(); torch.set_num_threads(4)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj): p.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
def check():
    if time.monotonic()-START>900: raise RuntimeError('15-minute stage budget exceeded; partial results preserved')
class Model(nn.Module):
    def __init__(self,h):
        super().__init__(); self.first=Layer(12,h,8); self.second=Layer(h,1,8)
        # The frozen-score inference helper initializes zero weights before loading.
        # New training must use the archived training implementation's initialization.
        for layer in (self.first,self.second):
            with torch.no_grad():
                layer.coeff.copy_(torch.randn_like(layer.coeff)*.025)
                layer.base.copy_(torch.randn_like(layer.base)/np.sqrt(layer.base.shape[1]))
    def forward(self,x): return self.second(4*torch.tanh(self.first(x)/4)).flatten()
def predict(m,x):
    with torch.no_grad(): return np.concatenate([torch.sigmoid(m(torch.tensor(b,dtype=torch.float32))).numpy() for b in np.array_split(x,max(1,int(np.ceil(len(x)/2048))))])
def metric(y,p,t):
    a=p>=t; truth=y==1; tp=int((a&truth).sum()); fp=int((a&~truth).sum()); fn=int((~a&truth).sum()); tn=int((~a&~truth).sum())
    return dict(ventricular_f1=2*tp/max(2*tp+fp+fn,1),sensitivity=tp/max(tp+fn,1),precision=tp/max(tp+fp,1),specificity=tn/max(tn+fp,1),tp=tp,fp=fp,fn=fn,tn=tn)
source=P1/'beat_features_unscaled.csv'; protocol=HERE/'BROAD_EXTENSION_PROTOCOL.md'
save(OUT/'input_hashes.json',{str(p.relative_to(ROOT)):sha(p) for p in (source,protocol,Path(__file__))})
df=pd.read_csv(source,dtype={'record_id':str}); names=json.loads((P1/'feature_schema.json').read_text())['feature_order']; x=df[names].to_numpy(); y=df.label.to_numpy(); groups=df.record_id.replace({'202':'201'}).to_numpy()
assert len(np.unique(groups))==43
outer=GroupShuffleSplit(n_splits=3,test_size=.25,random_state=20261004); rows=[]; selected=[]; predictions=[]
for split,(dev,test) in enumerate(outer.split(x,y,groups)):
    inner=GroupShuffleSplit(n_splits=1,test_size=.25,random_state=20261004+split); a,b=next(inner.split(x[dev],y[dev],groups[dev])); train,val=dev[a],dev[b]
    assert set(groups[train]).isdisjoint(groups[val]) and set(groups[train]).isdisjoint(groups[test]) and set(groups[val]).isdisjoint(groups[test])
    for ids in (train,val,test): assert len(np.unique(y[ids]))==2
    partition=np.full(len(df),'test',dtype=object); partition[train]='train'; partition[val]='validation'
    pd.DataFrame(dict(record_id=df.record_id,annotation_sample=df.annotation_sample,source_group=groups,partition=partition)).to_csv(OUT/f'split{split}_membership.csv',index=False)
    imputer=SimpleImputer(strategy='median'); scaler=StandardScaler(); xt=scaler.fit_transform(imputer.fit_transform(x[train])).astype('float32'); xv=scaler.transform(imputer.transform(x[val])).astype('float32'); xe=scaler.transform(imputer.transform(x[test])).astype('float32')
    joblib.dump(dict(imputer=imputer,scaler=scaler),OUT/'models'/f'split{split}_transforms.joblib'); np.savez_compressed(OUT/f'split{split}_feature_arrays.npz',train_X=xt,validation_X=xv,test_X=xe,train_ids=train,validation_ids=val,test_ids=test)
    for family in ('random_forest','mlp','kan'):
        options=[]
        for configuration in (1,5) if family=='random_forest' else (16,32) if family=='mlp' else (8,16):
            check(); start=time.monotonic(); cid=f's{split}_{family}_{configuration}'; history=[]; fit_warnings=[]
            if family=='kan':
                np.random.seed(17); torch.manual_seed(17); model=Model(configuration); optimizer=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.0001)
                lossfn=nn.BCEWithLogitsLoss(pos_weight=torch.tensor(float((len(train)-y[train].sum())/y[train].sum())))
                tx=torch.tensor(xt); ty=torch.tensor(y[train],dtype=torch.float32); best=-1; state=None; stale=0
                for epoch in range(60):
                    check(); model.train()
                    for ids in torch.randperm(len(tx)).split(1024):
                        optimizer.zero_grad(); loss=lossfn(model(tx[ids]),ty[ids])+1e-5*(model.first.coeff.abs().mean()+model.second.coeff.abs().mean()); loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5); optimizer.step()
                    model.eval(); s=predict(model,xv); t=threshold(y[val],s); value=metric(y[val],s,t)['ventricular_f1']; history.append(dict(epoch=epoch+1,validation_f1=value))
                    if value>best: best=value; state=copy.deepcopy(model.state_dict()); stale=0
                    else: stale+=1
                    if stale>=10: break
                model.load_state_dict(state); model.eval(); s=predict(model,xv); torch.save(dict(state_dict=state,hidden=configuration,grid=8),OUT/'models'/f'{cid}.pt')
            else:
                model=RandomForestClassifier(n_estimators=120,min_samples_leaf=configuration,class_weight='balanced',random_state=17,n_jobs=4) if family=='random_forest' else MLPClassifier(hidden_layer_sizes=(configuration,),alpha=.001,max_iter=120,early_stopping=False,random_state=17)
                with warnings.catch_warnings(record=True) as rec:
                    warnings.simplefilter('always'); model.fit(xt,y[train]); fit_warnings=[str(w.message) for w in rec]
                s=model.predict_proba(xv)[:,1]; joblib.dump(model,OUT/'models'/f'{cid}.joblib')
            t=threshold(y[val],s); mm=metric(y[val],s,t); row=dict(candidate_id=cid,split=split,family=family,configuration=configuration,threshold=t,training_seconds=time.monotonic()-start,**mm); rows.append(row); options.append((row,model))
            np.savez_compressed(OUT/'models'/f'{cid}_validation.npz',score=s,label=y[val]); save(OUT/'models'/f'{cid}_fit.json',dict(history=history,warnings=fit_warnings,validation=row)); pd.DataFrame(rows).to_csv(OUT/'configuration_validation.csv',index=False)
            print('FITTED',cid,round(mm['ventricular_f1'],4),flush=True)
        row,model=max(options,key=lambda a:(a[0]['ventricular_f1'],-a[0]['configuration'])); s=predict(model,xe) if family=='kan' else model.predict_proba(xe)[:,1]
        selected.append(dict(split=split,family=family,candidate_id=row['candidate_id'],threshold=row['threshold'],train_groups=len(np.unique(groups[train])),validation_groups=len(np.unique(groups[val])),test_groups=len(np.unique(groups[test])),**metric(y[test],s,row['threshold'])))
        predictions.append(pd.DataFrame(dict(split=split,family=family,record_id=df.record_id.iloc[test].to_numpy(),source_group=groups[test],annotation_sample=df.annotation_sample.iloc[test].to_numpy(),label=y[test],score=s,threshold=row['threshold'])))
        pd.DataFrame(selected).to_csv(OUT/'selected_test_metrics.csv',index=False); pd.concat(predictions,ignore_index=True).to_csv(OUT/'test_predictions.csv',index=False)
summary=dict(status='COMPLETE',source_groups=len(np.unique(groups)),split_count=3,configuration_fits=len(rows),selected_evaluations=len(selected),cpu_seconds=time.monotonic()-START,gpu_used=False,exploratory=True,test_reuse=True)
save(OUT/'summary.json',summary); save(OUT/'output_hashes.json',{str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='output_hashes.json'}); print(json.dumps(summary))
