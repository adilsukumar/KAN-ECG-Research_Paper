"""No GPU or teacher inference; numerical controls and frozen-score extension."""
import os, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
if sys.version_info[:2]==(3,11): sys.path.insert(0,str(HERE/'runtime'))
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'): os.environ[key]='4'
import json, hashlib, time, warnings
import numpy as np
import pandas as pd
import scipy, sklearn
from scipy.special import expit, logit
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import orthogonal_mp_gram
from sklearn.metrics import r2_score
OUT=HERE/'control_outputs'; OUT.mkdir(exist_ok=True); (OUT/'expressions').mkdir(exist_ok=True)
ROOT=HERE.parent; P1=ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'
START=time.monotonic()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj): p.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
def fit(a,target,w,count,normalized):
    am=np.average(a,axis=0,weights=w); tm=float(np.average(target,weights=w)); ac=a-am
    gram=ac.T@(ac*w[:,None]); xy=ac.T@((target-tm)*w)
    norm=np.sqrt(np.maximum(np.diag(gram),1e-30)) if normalized else np.ones(a.shape[1])
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter('always')
        coef=orthogonal_mp_gram(gram/norm[:,None]/norm[None,:],xy/norm,n_nonzero_coefs=count)/norm
    return float(tm-am@coef),coef,[str(v.message) for v in rec]
def score(e,x):
    z=np.clip(x,-4,4).astype(float); raw=np.full(len(z),e['intercept'])
    for t in e['terms']: raw+=t['coefficient']*np.prod(z**np.array(t['powers']),axis=1)
    return expit(raw) if e['link']=='sigmoid' else np.clip(raw,0,1)
def threshold(y,s):
    ix=np.argsort(-s,kind='stable'); a=y[ix]; b=s[ix]; tp=np.cumsum(a); fp=np.cumsum(1-a)
    f=2*tp/np.maximum(tp+fp+y.sum(),1)
    pool=np.flatnonzero(np.r_[b[1:]!=b[:-1],True] & (tp/y.sum()>=.90))
    return float(b[pool[np.argmax(f[pool])]])
def metrics(y,s,t,p,pt):
    pred=s>=t; truth=y==1; tp=int((pred&truth).sum()); fp=int((pred&~truth).sum()); fn=int((~pred&truth).sum())
    sensitivity=tp/truth.sum(); teacher_sens=((p>=pt)&truth).sum()/truth.sum()
    return dict(fidelity_r2=float(r2_score(p,s)),probability_rmse=float(np.sqrt(np.mean((p-s)**2))),decision_agreement=float(np.mean(pred==(p>=pt))),sensitivity=float(sensitivity),sensitivity_loss=float(teacher_sens-sensitivity),ventricular_f1=2*tp/max(2*tp+fp+fn,1),tp=tp,fp=fp,fn=fn)
inputs=[Path(__file__),HERE/'CONTROL_PROTOCOL.md',P1/'train_arrays.npz',P1/'validation_arrays.npz',HERE/'pilot_outputs/teacher_validation.csv',HERE/'pilot_outputs/validation_candidates.csv']+[HERE/f'pilot_outputs/{m}_teacher_scores.npz' for m in ('kan','random_forest','mlp')]
save(OUT/'input_hashes.json',{str(p.relative_to(ROOT)):sha(p) for p in inputs})
prior=json.loads((HERE/'pilot_outputs/audit.json').read_text())['output_sha256']
for p in inputs:
    if p.parent==HERE/'pilot_outputs': assert sha(p)==prior[p.name],p.name
save(OUT/'environment.json',dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,cpu_threads=4,gpu_used=False))
controls=[]
for seed in (17,43,89):
    rng=np.random.default_rng(seed); x=rng.uniform(-1,1,(6000,12)); train=x[:4000]; val=x[4000:]
    for degree in (1,2):
        poly=PolynomialFeatures(degree,include_bias=False); a=poly.fit_transform(train); b=poly.transform(val)
        for link in ('sigmoid','clip_probability'):
            intercept=.2 if link=='sigmoid' else .5
            scale=1 if link=='sigmoid' else .1
            true=np.zeros(a.shape[1])
            powers=[(0,1),(3,1)] if degree==1 else [(0,2),(3,1),(5,1)]
            values=[.7,-.4] if degree==1 else [.7,-.4,.3]
            for (feature,power),value in zip(powers,values):
                index=np.flatnonzero((poly.powers_[:,feature]==power)&(poly.powers_.sum(axis=1)==power))[0]; true[index]=value*scale
            raw=a@true+intercept; ref=b@true+intercept
            target=raw; expected=expit(ref) if link=='sigmoid' else np.clip(ref,0,1)
            for normalized in (False,True):
                offset,coef,_=fit(a,target,np.ones(len(a)),len(values),normalized)
                predicted=expit(b@coef+offset) if link=='sigmoid' else np.clip(b@coef+offset,0,1)
                r2=float(r2_score(expected,predicted)); rmse=float(np.sqrt(np.mean((expected-predicted)**2)))
                controls.append(dict(seed=seed,degree=degree,link=link,normalized=normalized,fidelity_r2=r2,rmse=rmse,coefficient_max_error=float(abs(coef-true).max()),passed=r2>=.999999 and rmse<=1e-6))
                np.savez_compressed(OUT/f'control_s{seed}_d{degree}_{link}_n{int(normalized)}.npz',validation_probability=predicted,coefficient=coef,intercept=offset)
pd.DataFrame(controls).to_csv(OUT/'positive_controls.csv',index=False)
train=np.load(P1/'train_arrays.npz',allow_pickle=False); val=np.load(P1/'validation_arrays.npz',allow_pickle=False)
xt,xv=train['X'],val['X']; yt,yv=train['y'],val['y']; names=train['feature_names'].astype(str).tolist()
thresholds=pd.read_csv(HERE/'pilot_outputs/teacher_validation.csv').set_index('teacher').threshold.to_dict()
rows=[]
for degree in (1,2):
    poly=PolynomialFeatures(degree,include_bias=False); a=poly.fit_transform(np.clip(xt,-4,4).astype(float))
    for teacher in ('kan','random_forest','mlp'):
        cache=np.load(HERE/f'pilot_outputs/{teacher}_teacher_scores.npz',allow_pickle=False); pt,pv=cache['train'],cache['validation']
        for objective in ('logit','probability','class_probability','class_boundary_probability'):
            w=np.ones(len(yt)); target=logit(np.clip(pt,1e-5,1-1e-5)) if objective=='logit' else pt.astype(float)
            if objective.startswith('class'): w=np.where(yt==1,len(yt)/(2*yt.sum()),len(yt)/(2*(len(yt)-yt.sum())))
            if objective=='class_boundary_probability': w*=1+4*np.exp(-abs(pt-thresholds[teacher])/.05)
            w/=w.mean()
            for count in (1,2,3,4,5,6,8):
                assert time.monotonic()-START<180,'Budget reached; partial outputs retained'
                offset,coef,rec=fit(a,target,w,count,True); active=np.flatnonzero(abs(coef)>1e-12); link='sigmoid' if objective=='logit' else 'clip_probability'
                complexity=2 if link=='sigmoid' else 3
                for j in active:
                    power=poly.powers_[j]; n=int(np.count_nonzero(power)); complexity+=3+3*n+2*int(np.sum(power>1))+max(n-1,0)
                cid=f'{teacher}_{objective}_d{degree}_t{count}'
                expr=dict(candidate_id=cid,link=link,intercept=offset,terms=[dict(coefficient=float(coef[j]),powers=poly.powers_[j].tolist()) for j in active],standardized_features=names,input_clip=[-4,4],fit_warnings=rec)
                s=score(expr,xv); t=threshold(yv,s); mm=metrics(yv,s,t,pv,thresholds[teacher])
                gates=dict(fidelity=mm['fidelity_r2']>=.9,agreement=mm['decision_agreement']>=.95,sensitivity=mm['sensitivity']>=.9,complexity=complexity<=25,sensitivity_loss=mm['sensitivity_loss']<=.03)
                row=dict(candidate_id=cid,teacher=teacher,objective=objective,degree=degree,requested_terms=count,terms=len(active),complexity=complexity,threshold=t,qualifies=all(gates.values()),**{f'gate_{k}':v for k,v in gates.items()},**mm)
                expr.update(threshold=t,validation=row); save(OUT/'expressions'/f'{cid}.json',expr)
                np.savez_compressed(OUT/'expressions'/f'{cid}.npz',validation_probability=s,validation_prediction=(s>=t).astype(np.int8)); rows.append(row)
pd.DataFrame(rows).to_csv(OUT/'normalized_candidates.csv',index=False)
table=pd.DataFrame(rows); old=pd.read_csv(HERE/'pilot_outputs/validation_candidates.csv'); summary=[]
for teacher,g in table.groupby('teacher',sort=False):
    previous=old[old.teacher==teacher]; feasible=g[g.complexity<=25]
    summary.append(dict(teacher=teacher,old_best_r2=float(previous.fidelity_r2.max()),normalized_best_r2=float(g.fidelity_r2.max()),normalized_budget_best_r2=float(feasible.fidelity_r2.max()),accepted=int(g.qualifies.sum()),fidelity_pass=int(g.gate_fidelity.sum())))
save(OUT/'summary.json',dict(positive_controls=len(controls),unnormalized_control_passes=sum(c['passed'] for c in controls if not c['normalized']),normalized_control_passes=sum(c['passed'] for c in controls if c['normalized']),normalized_candidates=len(rows),teachers=summary,cpu_seconds=time.monotonic()-START,gpu_used=False,external_evaluation=False))
save(OUT/'output_hashes.json',{str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name not in ('output_hashes.json','independent_audit.json')})
print((OUT/'summary.json').read_text())
