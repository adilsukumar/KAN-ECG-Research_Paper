# Numerical controls and dictionary normalization findings

All 24 noiseless known-target fits pass probability R2 >= 0.999999 and RMSE <= 1e-6. Both original and normalized OMP recover these simple targets. This validates limited numerical recovery, not general physiological interpretability.

The additional 168 normalized fits retain every expression, warning, probability, prediction and gate. Maximum validation R2: KAN 0.5523, RF 0.8061, MLP 0.7761; within 25 nodes: 0.5245, 0.7883, 0.7047. None meets fidelity or all gates. Failures across teachers prevent attributing this limitation uniquely to KAN architecture.

Independent audit PASS: nine input hashes, 365 output hashes, 24 controls and 168 candidate metrics/thresholds/gates checked. Exact expression round trip; maximum independent metric-reduction discrepancy 2.21e-8, below recorded 1e-6 tolerance with identical gate outcomes. Cached float32 teacher variance and independent reduction precision differ slightly.

Final fitting execution: 6.17 CPU seconds, excluding setup, audit, manuscript work and preliminary execution. No retraining, external evaluation, GPU or Kaggle use. Original artifacts preserved. New paper: `../07_Paper/KAN_Arrhythmia_IEEE_Strengthened.docx`.

Additive/edgewise comparison, patient-resampling formula stability and untouched confirmation remain unperformed. No accepted diagnostic expression, universal KAN conclusion, breakthrough or publication/award guarantee is established.
