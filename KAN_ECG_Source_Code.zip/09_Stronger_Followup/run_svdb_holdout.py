"""Previously unused database holdout, frozen original weights and references."""
import os,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'): os.environ[k]='4'
import numpy as np,pandas as pd,torch,wfdb,joblib,json,hashlib,time,requests
from scipy.signal import butter,sosfiltfilt,resample
from concurrent.futures import ThreadPoolExecutor,as_completed
from run_distillation_pilot import KAN,kan_predict
from run_broader_surrogates import additive_predict,edge_predict
ROOT=HERE.parent; P1=ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'; P2=ROOT/'03_Phase2_Baselines/outputs/kaggle_download/phase2_clean'; REM=ROOT/'04_Phase3_KAN_Symbolic/outputs/kaggle_download/remaining_clean'
OUT=HERE/'svdb_holdout'; OUT.mkdir(exist_ok=True); RAW=OUT/'raw'; RAW.mkdir(exist_ok=True); START=time.monotonic(); torch.set_num_threads(4)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,obj): p.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
def metric(y,p,t):
    a=p>=t; truth=y==1; tp=int((a&truth).sum()); fp=int((a&~truth).sum()); fn=int((~a&truth).sum()); tn=int((~a&~truth).sum())
    return dict(ventricular_f1=2*tp/max(2*tp+fp+fn,1),sensitivity=tp/max(tp+fn,1),precision=tp/max(tp+fp,1),specificity=tn/max(tn+fp,1),tp=tp,fp=fp,fn=fn,tn=tn)
PROTOCOL=json.loads((P1/'study_protocol.json').read_text()); FEATURES=PROTOCOL['features']; POSITIVE=set(PROTOCOL['positive_symbols']); ELIGIBLE=POSITIVE|set(PROTOCOL['negative_symbols'])
nbpath=ROOT/'02_Phase1_Preprocessing/notebook/phase1_clean_preprocessing.ipynb'; nb=json.loads(nbpath.read_text(encoding='utf-8')); code=next(''.join(c['source']) for c in nb['cells'] if c['cell_type']=='code' and 'def choose_lead' in ''.join(c['source']))
selection=json.loads((HERE/'broader_outputs/selected_references.json').read_text()); references={m:json.loads((HERE/'broader_outputs/models'/f'{cid}.json').read_text()) for m,cid in selection.items() if m in ('additive','edgewise')}; polynomial=json.loads((HERE/'broader_outputs/fixed_polynomial_reference.json').read_text())
thresholds=pd.read_csv(HERE/'pilot_outputs/teacher_validation.csv').set_index('teacher').threshold.to_dict(); thresholds.update({m:e['validation']['threshold'] for m,e in references.items()},polynomial=polynomial['threshold'])
inputs=[Path(__file__),HERE/'BROAD_EXTENSION_PROTOCOL.md',nbpath,P1/'feature_imputer.joblib',P1/'feature_scaler.joblib',REM/'models/kan_h16_g16_s89.pt',P2/'models/random_forest.joblib',P2/'models/mlp.joblib',HERE/'broader_outputs/selected_references.json',HERE/'broader_outputs/fixed_polynomial_reference.json',HERE/'pilot_outputs/teacher_validation.csv']+[HERE/'broader_outputs/models'/f'{selection[m]}.json' for m in references]
save(OUT/'frozen_before_download.json',dict(input_sha256={str(p.relative_to(ROOT)):sha(p) for p in inputs},thresholds=thresholds,diagnostic_references=selection,source='https://physionet.org/content/svdb/1.0.0/',no_external_fitting=True,patient_independence_verified=False))
exec(compile(code,str(nbpath)+':feature_cell','exec'))
base='https://physionet.org/files/svdb/1.0.0/'
def download(filename):
    p=RAW/filename
    if p.exists() and p.stat().st_size: return p
    for attempt in range(3):
        try:
            r=requests.get(base+filename,timeout=(15,60)); r.raise_for_status(); p.write_bytes(r.content); return p
        except requests.RequestException:
            if attempt==2: raise
            time.sleep(1)
records=download('RECORDS').read_text().split(); assert len(records)==78 and len(set(records))==78
with ThreadPoolExecutor(max_workers=4) as pool:
    jobs=[pool.submit(download,record+'.'+suffix) for record in records for suffix in ('hea','atr','dat')]
    for i,f in enumerate(as_completed(jobs)):
        f.result()
        if (i+1)%39==0: print('Downloaded',i+1,'of',len(jobs),flush=True)
rows=[]; audits=[]
for i,name in enumerate(records):
    beatrows,_,audit=process_record(name,'new_database_holdout')
    for row in beatrows: row.update(database='svdb')
    rows.extend(beatrows); audits.append(audit)
    if (i+1)%13==0: print('Extracted',i+1,'of 78',flush=True)
df=pd.DataFrame(rows); df.to_csv(OUT/'features_unscaled.csv',index=False); save(OUT/'record_extraction_audit.json',audits)
imputer=joblib.load(P1/'feature_imputer.joblib'); scaler=joblib.load(P1/'feature_scaler.joblib'); x=scaler.transform(imputer.transform(df[FEATURES])).astype('float32'); y=df.label.to_numpy().astype(int); assert np.isfinite(x).all() and y.sum()>0
np.savez_compressed(OUT/'evaluation_arrays.npz',X=x,y=y,record_id=df.record_id.to_numpy().astype(str),annotation_sample=df.annotation_sample.to_numpy(),feature_names=np.array(FEATURES))
kan=KAN().eval(); kan.load_state_dict(torch.load(REM/'models/kan_h16_g16_s89.pt',map_location='cpu',weights_only=False)['state_dict']); scores={'kan':kan_predict(kan,x)}
for name in ('random_forest','mlp'): scores[name]=joblib.load(P2/'models'/f'{name}.joblib').predict_proba(x)[:,1]
scores['additive']=additive_predict(references['additive'],x); scores['edgewise']=edge_predict(references['edgewise'],x); scores['polynomial']=np.clip(np.clip(x,-4,4).astype(float)@np.array(polynomial['coefficient'])+polynomial['intercept'],0,1)
predictions=df[['record_id','annotation_sample','annotation_symbol','label','lead','lead_fallback']].copy(); results=[]
for name,s in scores.items():
    predictions[name+'_score']=s; predictions[name+'_prediction']=(s>=thresholds[name]).astype(int)
    row=dict(model=name,threshold=thresholds[name],diagnostic_surrogate=name in ('additive','edgewise','polynomial'),**metric(y,s,thresholds[name]))
    if row['diagnostic_surrogate']:
        row['teacher_probability_r2']=1-float(((scores['kan']-s)**2).sum()/((scores['kan']-scores['kan'].mean())**2).sum()); row['decision_agreement']=float(np.mean((s>=thresholds[name])==(scores['kan']>=thresholds['kan'])))
    results.append(row)
predictions.to_csv(OUT/'predictions.csv',index=False); pd.DataFrame(results).to_csv(OUT/'metrics.csv',index=False)
units=df.record_id.to_numpy(); rng=np.random.default_rng(20261004); draws=np.bincount # use identical record draws for every model
count=[]
for name,s in scores.items(): count.append(np.array([[metric(y[units==r],s[units==r],thresholds[name])[k] for k in ('tp','fp','fn')] for r in records]))
weights=np.array([np.bincount(rng.integers(0,78,78),minlength=78) for _ in range(1000)]); boot={}; ci=[]
for name,c in zip(scores,count):
    aggregate=weights@c; v=2*aggregate[:,0]/np.maximum(2*aggregate[:,0]+aggregate[:,1]+aggregate[:,2],1); sens=aggregate[:,0]/np.maximum(aggregate[:,0]+aggregate[:,2],1); valid=aggregate[:,0]+aggregate[:,2]>0
    boot[name]=v; ci.append(dict(model=name,f1_low=float(np.quantile(v[valid],.025)),f1_high=float(np.quantile(v[valid],.975)),sensitivity_low=float(np.quantile(sens[valid],.025)),sensitivity_high=float(np.quantile(sens[valid],.975)),valid_replicates=int(valid.sum())))
pd.DataFrame(ci).to_csv(OUT/'record_bootstrap_intervals.csv',index=False); difference=boot['kan']-boot['random_forest']; save(OUT/'paired_comparison.json',dict(comparison='KAN minus RF V-F1',low=float(np.quantile(difference,.025)),high=float(np.quantile(difference,.975)),replicates=1000,cluster='record',patient_independence_verified=False)); np.savez_compressed(OUT/'bootstrap_replicates.npz',weights=weights,**boot)
save(OUT/'summary.json',dict(status='COMPLETE',records=78,beats=len(df),ventricular_beats=int(y.sum()),fallback_records=int(pd.DataFrame(audits).lead_fallback.sum()),cpu_and_download_seconds=time.monotonic()-START,no_external_fitting=True,patient_independence_verified=False,gpu_used=False,missingness=df[FEATURES].isna().mean().to_dict(),raw_sha256={p.name:sha(p) for p in sorted(RAW.iterdir()) if p.is_file()}))
save(OUT/'output_hashes.json',{str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='output_hashes.json'}); print(pd.DataFrame(results).to_string(index=False)); print((OUT/'paired_comparison.json').read_text())
