"""Reproduce all 18 validation and nine selected test predictions from fitted files."""
import os,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'): os.environ[name]='4'
import numpy as np,pandas as pd,torch,joblib,json
from torch import nn
from run_distillation_pilot import Layer
torch.set_num_threads(4); OUT=HERE/'grouped_benchmark'
class Model(nn.Module):
    def __init__(self,h): super().__init__(); self.first=Layer(12,h,8); self.second=Layer(h,1,8)
    def forward(self,x): return self.second(4*torch.tanh(self.first(x)/4)).flatten()
def infer(row,x):
    path=OUT/'models'/row['candidate_id']
    if row['family']!='kan': return joblib.load(str(path)+'.joblib').predict_proba(x)[:,1]
    state=torch.load(str(path)+'.pt',map_location='cpu',weights_only=False); m=Model(state['hidden']).eval(); m.load_state_dict(state['state_dict'])
    with torch.no_grad(): return np.concatenate([torch.sigmoid(m(torch.tensor(b,dtype=torch.float32))).numpy() for b in np.array_split(x,max(1,int(np.ceil(len(x)/2048))))])
maximum=0
for row in pd.read_csv(OUT/'configuration_validation.csv').to_dict('records'):
    x=np.load(OUT/f"split{row['split']}_feature_arrays.npz",allow_pickle=False)['validation_X']; s=infer(row,x); saved=np.load(OUT/'models'/f"{row['candidate_id']}_validation.npz",allow_pickle=False)['score']; err=float(abs(s-saved).max()); maximum=max(maximum,err); assert err<2e-6
    assert np.array_equal(s>=row['threshold'],saved>=row['threshold'])
preds=pd.read_csv(OUT/'test_predictions.csv',float_precision='round_trip')
for row in pd.read_csv(OUT/'selected_test_metrics.csv').to_dict('records'):
    x=np.load(OUT/f"split{row['split']}_feature_arrays.npz",allow_pickle=False)['test_X']; s=infer(row,x); saved=preds.loc[(preds.split==row['split'])&(preds.family==row['family']),'score'].to_numpy(); err=float(abs(s-saved).max()); maximum=max(maximum,err); assert err<2e-6
report=dict(status='PASS',validation_models=18,test_models=9,maximum_score_discrepancy=maximum,inference_tolerance=2e-6,validation_decisions_exact=True)
(HERE/'grouped_model_inference_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(report))
