"""Read-only recomputation of serialized pilot expressions and validation gates."""
import json
from run_distillation_pilot import OUT, P1, ROOT, sha, score_expression, metrics, threshold, save
import numpy as np
import pandas as pd
import joblib

def main():
    audit=json.loads((OUT/'audit.json').read_text())
    for relative,expected in audit['output_sha256'].items():
        assert sha(OUT/relative)==expected,relative
    for relative,expected in json.loads((OUT/'protocol_and_input_hashes.json').read_text()).items():
        assert sha(ROOT/relative)==expected,relative
    val=np.load(P1/'validation_arrays.npz',allow_pickle=False)
    x,y=val['X'],val['y']
    teachers=pd.read_csv(OUT/'teacher_validation.csv',float_precision='round_trip').set_index('teacher')
    table=pd.read_csv(OUT/'validation_candidates.csv',float_precision='round_trip')
    maximum=0.
    for row in table.to_dict('records'):
        cid=row['candidate_id']
        expr=json.loads((OUT/'candidates'/f'{cid}.json').read_text())
        s=score_expression(expr,x)
        archived=np.load(OUT/'candidates'/f'{cid}.npz',allow_pickle=False)
        err=float(np.max(np.abs(s-archived['validation_probability'])))
        maximum=max(maximum,err); assert err<1e-9,cid
        t=expr['threshold']; assert t==row['threshold']
        assert t==threshold(y,archived['validation_probability'])
        p=np.load(OUT/f"{row['teacher']}_teacher_scores.npz",allow_pickle=False)['validation']
        m=metrics(y,s,t,p,float(teachers.loc[row['teacher'],'threshold']))
        # Compute classifications from the saved probabilities to avoid roundoff on threshold ties.
        stored=metrics(y,archived['validation_probability'],t,p,float(teachers.loc[row['teacher'],'threshold']))
        for key,value in stored.items(): assert abs(value-row[key])<1e-9,(cid,key)
        complexity=2 if expr['link']=='sigmoid' else 3
        for term in expr['terms']:
            power=np.array(term['powers']); n=int(np.count_nonzero(power))
            complexity+=3+3*n+2*int(np.sum(power>1))+max(n-1,0)
        assert complexity==row['complexity']
        gates=[stored['fidelity_r2']>=.9,stored['decision_agreement']>=.95,
               stored['sensitivity']>=.9,complexity<=25,stored['sensitivity_loss']<=.03]
        assert bool(row['qualifies'])==all(gates)
        assert np.array_equal(archived['validation_prediction'],(archived['validation_probability']>=t).astype(np.int8))
        assert np.array_equal(archived['validation_prediction'],(s>=t).astype(np.int8)),cid
    assert len(table)==168 and table.candidate_id.nunique()==168
    assert int(table.qualifies.sum())==audit['qualifying']
    trees=pd.read_csv(OUT/'tree_validation.csv',float_precision='round_trip')
    for row in trees.to_dict('records'):
        model=joblib.load(OUT/f"{row['teacher']}_tree_{row['max_leaves']}.joblib")
        s=model.predict(x)
        p=np.load(OUT/f"{row['teacher']}_teacher_scores.npz",allow_pickle=False)['validation']
        assert threshold(y,s)==row['threshold']
        mm=metrics(y,s,row['threshold'],p,float(teachers.loc[row['teacher'],'threshold']))
        for key,value in mm.items(): assert abs(value-row[key])<1e-9,(row['teacher'],key)
    result=dict(status='PASS',candidate_metrics_recomputed=len(table),hashes_verified=len(audit['output_sha256']),
                maximum_serialized_probability_error=maximum,qualifying=int(table.qualifies.sum()),
                tree_baseline_metrics_recomputed=len(trees),
                clinical_or_independent_validation_claim=False)
    save(OUT.parent/'independent_pilot_audit.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
