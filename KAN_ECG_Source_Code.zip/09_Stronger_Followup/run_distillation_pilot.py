"""Bounded frozen-teacher CPU pilot. See PILOT_PROTOCOL.md before execution."""
import os, sys
from pathlib import Path
_runtime = Path(__file__).resolve().parent/'runtime'
if _runtime.exists():
    sys.path.insert(0,str(_runtime))
for _name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_name] = '4'
import hashlib, json, time, warnings
import numpy as np
import pandas as pd
import torch
from torch import nn
import joblib
import sklearn, scipy
from scipy.special import expit, logit
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import orthogonal_mp_gram
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import r2_score

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
OUT = HERE/'pilot_outputs'
P1 = ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'
P2 = ROOT/'03_Phase2_Baselines/outputs/kaggle_download/phase2_clean'
REM = ROOT/'04_Phase3_KAN_Symbolic/outputs/kaggle_download/remaining_clean'
START = time.monotonic()
torch.set_num_threads(4)

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()

def save(path, value):
    path.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8')

def budget():
    if time.monotonic()-START > 900:
        raise RuntimeError('CPU pilot time budget exhausted; partial outputs preserved')

class Layer(nn.Module):
    def __init__(self,i,o,g=16):
        super().__init__()
        self.register_buffer('knots',torch.linspace(-4,4,g+1))
        self.delta=8/g
        self.coeff=nn.Parameter(torch.zeros(o,i,g+1))
        self.base=nn.Parameter(torch.zeros(o,i))
        self.bias=nn.Parameter(torch.zeros(o))
    def forward(self,x):
        z=x.clamp(-4,4)
        b=(1-(z[:,:,None]-self.knots).abs()/self.delta).clamp_min(0)
        return nn.functional.linear(b.flatten(1),self.coeff.flatten(1))+nn.functional.linear(nn.functional.silu(z),self.base,self.bias)

class KAN(nn.Module):
    def __init__(self):
        super().__init__(); self.first=Layer(12,16); self.second=Layer(16,1)
    def forward(self,x):
        return self.second(4*torch.tanh(self.first(x)/4)).flatten()

def kan_predict(model,x):
    with torch.no_grad():
        return np.concatenate([torch.sigmoid(model(torch.tensor(b,dtype=torch.float32))).numpy()
                               for b in np.array_split(x,max(1,int(np.ceil(len(x)/4096))))])

def threshold(y,s):
    ix=np.argsort(-s,kind='stable'); a=y[ix]; b=s[ix]
    tp=np.cumsum(a); fp=np.cumsum(1-a)
    f=2*tp/np.maximum(tp+fp+y.sum(),1)
    pool=np.flatnonzero(np.r_[b[1:]!=b[:-1],True] & (tp/y.sum()>=.90))
    assert len(pool)
    return float(b[pool[np.argmax(f[pool])]])

def metrics(y,s,t,teacher,teacher_t):
    p=s>=t; truth=y==1
    tp=int((p&truth).sum()); fn=int((~p&truth).sum()); fp=int((p&~truth).sum())
    sens=tp/max(tp+fn,1)
    teacher_sens=float(((teacher>=teacher_t)&truth).sum()/truth.sum())
    return dict(fidelity_r2=float(r2_score(teacher,s)),probability_rmse=float(np.sqrt(np.mean((teacher-s)**2))),
                ventricular_probability_rmse=float(np.sqrt(np.mean((teacher[truth]-s[truth])**2))),
                nonventricular_probability_rmse=float(np.sqrt(np.mean((teacher[~truth]-s[~truth])**2))),
                decision_agreement=float(np.mean(p==(teacher>=teacher_t))),
                ventricular_f1=2*tp/max(2*tp+fp+fn,1),sensitivity=sens,
                sensitivity_loss=teacher_sens-sens,brier=float(np.mean((s-y)**2)),tp=tp,fp=fp,fn=fn)

def score_expression(expr,x):
    z=np.clip(x,-4,4).astype(np.float64)
    result=np.full(len(z),expr['intercept'])
    for term in expr['terms']:
        result += term['coefficient']*np.prod(z**np.asarray(term['powers']),axis=1)
    return expit(result) if expr['link']=='sigmoid' else np.clip(result,0,1)

def main():
    OUT.mkdir(exist_ok=True); (OUT/'candidates').mkdir(exist_ok=True)
    save(OUT/'environment.json',dict(python=sys.version,numpy=np.__version__,pandas=pd.__version__,
         scipy=scipy.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__,torch=torch.__version__,
         cpu_threads=4,gpu_used=False))
    source=[HERE/'PILOT_PROTOCOL.md',Path(__file__),P1/'train_arrays.npz',P1/'validation_arrays.npz',
            P1/'feature_imputer.joblib',P1/'feature_scaler.joblib',REM/'frozen_pipeline.json',
            REM/'models/kan_h16_g16_s89.pt',P2/'selected_models.json',
            P2/'models/random_forest.joblib',P2/'models/mlp.joblib']
    save(OUT/'protocol_and_input_hashes.json',{str(p.relative_to(ROOT)):sha(p) for p in source})
    # Verify original hashes before deserializing trusted workspace checkpoints.
    for folder in (P1,P2,REM):
        hashes=json.loads((folder/'artifact_hashes.json').read_text())
        for p in source:
            if p.is_relative_to(folder):
                relative=p.relative_to(folder).as_posix()
                assert sha(p)==hashes[relative],relative
    train=np.load(P1/'train_arrays.npz',allow_pickle=False)
    val=np.load(P1/'validation_arrays.npz',allow_pickle=False)
    xt,xv=train['X'],val['X']; yt,yv=train['y'],val['y']
    names=train['feature_names'].astype(str).tolist()
    assert set(train['record_id']).isdisjoint(val['record_id'])
    state=torch.load(source[7],map_location='cpu',weights_only=False)
    kan=KAN().eval(); kan.load_state_dict(state['state_dict'])
    models={'kan':kan,'random_forest':joblib.load(source[9]),'mlp':joblib.load(source[10])}
    selected=json.loads((P2/'selected_models.json').read_text())
    thresholds={'kan':json.loads((REM/'frozen_pipeline.json').read_text())['teacher']['threshold'],
                **{m:selected[m]['threshold'] for m in ('random_forest','mlp')}}
    scores={}; teacher_rows=[]
    for name,model in models.items():
        budget()
        pred=lambda x: kan_predict(model,x) if name=='kan' else model.predict_proba(x)[:,1]
        a,b=pred(xt),pred(xv); scores[name]=(a,b)
        mm=metrics(yv,b,thresholds[name],b,thresholds[name])
        reference=state['selection']['ventricular_f1'] if name=='kan' else selected[name]['validation_ventricular_f1']
        assert abs(mm['ventricular_f1']-reference)<1e-10,(name,mm,reference)
        teacher_rows.append(dict(teacher=name,threshold=thresholds[name],**mm))
        np.savez_compressed(OUT/f'{name}_teacher_scores.npz',train=a,validation=b,
                            train_record_id=train['record_id'],validation_record_id=val['record_id'])
    pd.DataFrame(teacher_rows).to_csv(OUT/'teacher_validation.csv',index=False)
    # Inference-only reproduction check; no fitting or selection from DS2.
    test=np.load(P1/'locked_test_arrays.npz',allow_pickle=False)
    archived=pd.read_csv(REM/'ds2_predictions.csv',dtype={'record_id':str})
    assert np.array_equal(test['record_id'].astype(str),archived.record_id.to_numpy())
    discrepancy=float(np.abs(kan_predict(kan,test['X'])-archived.kan_score.to_numpy()).max())
    assert discrepancy<2e-6,discrepancy
    rows=[]; maximum_roundtrip=0.
    for degree in (1,2):
        poly=PolynomialFeatures(degree,include_bias=False)
        a=poly.fit_transform(np.clip(xt,-4,4).astype(np.float64))
        b=poly.transform(np.clip(xv,-4,4).astype(np.float64))
        for name,(pt,pv) in scores.items():
            for objective in ('logit','probability','class_probability','class_boundary_probability'):
                budget(); w=np.ones(len(yt))
                target=logit(np.clip(pt,1e-5,1-1e-5)) if objective=='logit' else pt.astype(float)
                if objective.startswith('class'):
                    w=np.where(yt==1,len(yt)/(2*yt.sum()),len(yt)/(2*(len(yt)-yt.sum())))
                if objective=='class_boundary_probability':
                    w *= 1+4*np.exp(-np.abs(pt-thresholds[name])/.05)
                w/=w.mean(); am=np.average(a,axis=0,weights=w); tm=float(np.average(target,weights=w))
                ac=a-am; tc=target-tm
                gram=ac.T@(ac*w[:,None]); xy=ac.T@(tc*w)
                for count in (1,2,3,4,5,6,8):
                    with warnings.catch_warnings(record=True) as recorded:
                        warnings.simplefilter('always')
                        coef=orthogonal_mp_gram(gram,xy,n_nonzero_coefs=count)
                    intercept=float(tm-am@coef); active=np.flatnonzero(abs(coef)>1e-12)
                    link='sigmoid' if objective=='logit' else 'clip_probability'
                    complexity=2 if link=='sigmoid' else 3
                    for j in active:
                        power=poly.powers_[j]; n=int(np.count_nonzero(power))
                        complexity += 3+3*n+2*int(np.sum(power>1))+max(n-1,0)
                    raw=b@coef+intercept; sv=expit(raw) if link=='sigmoid' else np.clip(raw,0,1)
                    # Use the deployed evaluator before threshold selection; matrix-product
                    # rounding must not change decisions at exact threshold ties.
                    canonical=dict(link=link,intercept=intercept,
                        terms=[dict(coefficient=float(coef[j]),powers=poly.powers_[j].tolist()) for j in active])
                    deployed=score_expression(canonical,xv)
                    assert float(np.abs(deployed-sv).max())<1e-9
                    sv=deployed
                    th=threshold(yv,sv); mm=metrics(yv,sv,th,pv,thresholds[name])
                    gates={'fidelity':mm['fidelity_r2']>=.9,'agreement':mm['decision_agreement']>=.95,
                           'sensitivity':mm['sensitivity']>=.9,'complexity':complexity<=25,
                           'sensitivity_loss':mm['sensitivity_loss']<=.03}
                    cid=f'{name}_{objective}_d{degree}_t{count}'
                    row=dict(candidate_id=cid,teacher=name,objective=objective,degree=degree,
                             requested_terms=count,terms=len(active),complexity=complexity,threshold=th,
                             qualifies=all(gates.values()),**{f'gate_{k}':v for k,v in gates.items()},**mm)
                    expr=dict(candidate_id=cid,link=link,intercept=intercept,threshold=th,
                              standardized_features=names,input_clip=[-4,4],
                              terms=[dict(coefficient=float(coef[j]),powers=poly.powers_[j].tolist()) for j in active],
                              validation=row,fit_warnings=[str(v.message) for v in recorded])
                    save(OUT/'candidates'/f'{cid}.json',expr)
                    roundtrip=score_expression(json.loads((OUT/'candidates'/f'{cid}.json').read_text()),xv)
                    err=float(np.abs(roundtrip-sv).max()); maximum_roundtrip=max(maximum_roundtrip,err)
                    assert err<1e-9,(cid,err)
                    np.savez_compressed(OUT/'candidates'/f'{cid}.npz',validation_probability=sv,
                                        validation_prediction=(sv>=th).astype(np.int8))
                    rows.append(row)
                pd.DataFrame(rows).to_csv(OUT/'validation_candidates.csv',index=False)
                print('CHECKPOINT',name,objective,'degree',degree,flush=True)
    tree_rows=[]
    for name,(pt,pv) in scores.items():
        for leaves in (2,4,8):
            budget()
            tree=DecisionTreeRegressor(max_leaf_nodes=leaves,min_samples_leaf=200,random_state=20261001)
            tree.fit(xt,pt); sv=tree.predict(xv); th=threshold(yv,sv)
            joblib.dump(tree,OUT/f'{name}_tree_{leaves}.joblib')
            tree_rows.append(dict(teacher=name,max_leaves=leaves,actual_nodes=tree.tree_.node_count,
                                  threshold=th,**metrics(yv,sv,th,pv,thresholds[name])))
    pd.DataFrame(tree_rows).to_csv(OUT/'tree_validation.csv',index=False)
    table=pd.DataFrame(rows); chosen=[]
    for _,group in table.loc[table.qualifies].groupby(['teacher','objective']):
        chosen.append(group.sort_values(['ventricular_f1','complexity','fidelity_r2','candidate_id'],
                                        ascending=[False,True,False,True]).iloc[0].candidate_id)
    save(OUT/'selected_candidates.json',dict(candidate_ids=chosen,selection_data='validation only'))
    # No external result-driven expansion. Save original-study diagnostics separately.
    evaluation=[]
    if chosen:
        imputer=joblib.load(P1/'feature_imputer.joblib'); scaler=joblib.load(P1/'feature_scaler.joblib')
        external=pd.read_csv(REM/'incart_features_unscaled.csv',dtype={'record_id':str})
        xp=scaler.transform(imputer.transform(external[names])).astype(np.float32)
        ep=pd.read_csv(REM/'incart_predictions.csv',dtype={'record_id':str})
        assert np.array_equal(external.record_id.to_numpy(),ep.record_id.to_numpy())
        assert np.array_equal(external.label.to_numpy(),ep.label.to_numpy())
        for cid in chosen:
            expr=json.loads((OUT/'candidates'/f'{cid}.json').read_text()); teacher=expr['validation']['teacher']
            for cohort,x,y,reference in [('ds2',test['X'],test['y'],archived),('incart',xp,external.label.to_numpy(),ep)]:
                sv=score_expression(expr,x)
                mm=metrics(y,sv,expr['threshold'],reference[f'{teacher}_score'].to_numpy(),thresholds[teacher])
                evaluation.append(dict(candidate_id=cid,cohort=cohort,**mm))
                np.savez_compressed(OUT/f'{cid}_{cohort}.npz',probability=sv,label=y,record_id=reference.record_id.to_numpy(str))
        pd.DataFrame(evaluation).to_csv(OUT/'exploratory_selected_evaluation.csv',index=False)
    summary=table.groupby(['teacher','objective']).agg(candidates=('candidate_id','size'),
              qualifying=('qualifies','sum'),best_r2=('fidelity_r2','max')).reset_index()
    summary.to_csv(OUT/'validation_summary.csv',index=False)
    audit=dict(status='PASS',candidates=len(rows),qualifying=int(table.qualifies.sum()),
               selected=len(chosen),tree_baselines=len(tree_rows),teacher_fitting=False,gpu_used=False,
               new_independent_validation=False,candidate_roundtrip_max_error=maximum_roundtrip,
               kan_archived_ds2_max_error=discrepancy,seconds=time.monotonic()-START,
               output_sha256={p.relative_to(OUT).as_posix():sha(p) for p in OUT.rglob('*') if p.is_file() and p.name!='audit.json'})
    save(OUT/'audit.json',audit)
    print(summary.to_string(index=False)); print('AUDIT_PASS',audit['seconds'],'seconds',flush=True)

if __name__=='__main__': main()
