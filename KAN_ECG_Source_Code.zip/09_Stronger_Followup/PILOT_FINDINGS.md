# Frozen teacher distillation pilot findings

## Outcome

The prespecified CPU feasibility test is complete. All 168 polynomial candidates failed the probability-fidelity gate R² >= 0.90. No candidate passed all five gates. No new predictive or symbolic breakthrough has been established. The search stops at its planned validation gate rather than expanding compute or relaxing criteria.

The final pilot took 17.4 seconds of execution, excluding compatible-runtime installation and audit. An initial runtime mismatch was repaired in an isolated project-local package directory; original checkpoints and system packages were not modified. A second deterministic execution made serialized expression evaluation the numerical authority before threshold selection, avoiding floating-point differences at exact threshold ties. This was an implementation repair, not a new objective, dictionary, gate or test-driven tuning step.

## Objective ablations

Each row summarizes fourteen degree-one/two candidates at seven term budgets. Best R² is over all attempted complexity budgets, not just the acceptable 25-node budget.

| Teacher | Logit baseline best R² | Probability target best R² | Class balanced best R² | Class and boundary weighted best R² | Qualifying candidates |
| --- | ---: | ---: | ---: | ---: | ---: |
| KAN | 0.4449 | 0.5202 | 0.2576 | -0.5774 | 0 of 56 |
| Random Forest | 0.5257 | 0.7713 | 0.2627 | 0.2658 | 0 of 56 |
| MLP | 0.7274 | 0.5252 | 0.7761 | 0.7019 | 0 of 56 |

Probability targeting increased KAN's best global validation fidelity but did not approach the 0.90 gate. That best probability-targeted KAN candidate used six terms and 39 nodes, already above the 25-node gate. Class and boundary weighting did not deliver the hypothesized global fidelity improvement for this KAN. Their losses emphasize different training examples, so lower unweighted R² alone does not prove that weighting is universally harmful; class-specific RMSE, agreement and sensitivity diagnostics are retained in the complete results.

Across the 168 candidates, fidelity failed in 168, decision agreement in 151, complexity in 107 and sensitivity loss in 93. Absolute sensitivity passed in all 168 because thresholds were selected under the original validation constraint; this is not independent evidence of clinical safety. Candidate selection never consulted DS2 or INCART results.

Nine shallow decision-tree probability-distillation baselines were also fitted, with maximum leaf budgets 2, 4 and 8 per teacher. Their best validation probability R² values were 0.3316 for KAN, 0.5395 for Random Forest and 0.1017 for MLP. Node/leaf counts are not equated with the polynomial expression complexity gate. This bounded shallow-tree family is a minimal reference, not an exhaustive strong interpretable-model benchmark. Additive-model comparisons and patient-resampling formula stability have not been performed.

## Verification and saved evidence

All original inputs used by the pilot passed their retained SHA-256 checks. Frozen teacher validation F1 values reproduced their archived selections. KAN inference reproduced archived DS2 scores with maximum absolute probability difference 7.58e-7; this was an implementation check only, not surrogate selection.

Every attempted polynomial has saved coefficients, intercept, powers, input clipping, output link, threshold, validation metrics, gate flags and validation probabilities/predictions. The deployed expression evaluator reproduces all saved probabilities and classifications. A separate audit recomputes all candidate metrics and gate outcomes and verifies the 355 saved-output hashes. The shallow-tree metrics are also recomputed from their saved models. Full environment versions and protocol/input hashes are saved.

No teacher was retrained, no GPU or Kaggle quota was consumed, and no revised surrogate was evaluated on DS2 or INCART because none qualified. Previously completed dataset-shift and calibration diagnostics remain explicitly exploratory. No new independent external validation has been performed.

## Research decision

The simple weighted-polynomial strategy has not demonstrated a major contribution. Do not describe this pilot as successful symbolic recovery or award-level research. It strengthens the comparative negative evidence and repairs expression-retention shortcomings, but broader significance and novelty require a dedicated literature assessment.

The next scientifically distinct direction to assess is edge-wise approximation of the frozen spline KAN, with explicit propagated probability-error bounds and complete composed-expression complexity. Before spending compute, establish whether it differs from existing KAN symbolic extraction and component-level distillation. An exact piecewise-spline export would be faithful but could be large; an approximation bound is not a compactness or diagnostic-safety guarantee. Do not claim mathematical certification without proof and numerical verification on a specified domain. New independent evaluation remains necessary for any developed method.

The audited original paper is preserved. The requested twenty-page main article remains pending substantive new evidence and venue-specific requirements; it has not been produced by relabeling supplementary tables or inventing results. No public publishing, paid compute or award guarantee.
