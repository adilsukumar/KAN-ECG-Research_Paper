"""Explicit post-hoc descriptive comparison; no fitting/selection changes."""
from pathlib import Path
import sys,json,hashlib
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
import numpy as np,pandas as pd
folder=HERE/'svdb_holdout'; ar=np.load(folder/'bootstrap_replicates.npz',allow_pickle=False); metrics=pd.read_csv(folder/'metrics.csv').set_index('model')
delta=ar['additive']-ar['kan']
report=dict(comparison='Diagnostic additive minus frozen KAN V-F1',point_difference=float(metrics.loc['additive','ventricular_f1']-metrics.loc['kan','ventricular_f1']),low=float(np.quantile(delta,.025)),high=float(np.quantile(delta,.975)),replicates=1000,cluster='record',prespecified_primary=False,post_hoc=True,multiplicity_adjusted=False,no_new_fitting=True,accepted_surrogate=False,patient_independence_verified=False,input_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (folder/'bootstrap_replicates.npz',folder/'metrics.csv',Path(__file__))})
(HERE/'secondary_svdb_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps(report,indent=2))
