"""Frozen-score additive, edgewise and conditional stability comparisons."""
import os,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE/'runtime'))
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'): os.environ[key]='4'
import numpy as np, pandas as pd, json,hashlib,time,warnings,torch
from scipy.special import expit
from sklearn.linear_model import orthogonal_mp_gram
from sklearn.metrics import r2_score
from run_distillation_pilot import KAN,kan_predict,threshold,metrics,score_expression
ROOT=HERE.parent; P1=ROOT/'02_Phase1_Preprocessing/outputs/kaggle_download/phase1_clean'; REM=ROOT/'04_Phase3_KAN_Symbolic/outputs/kaggle_download/remaining_clean'
OUT=HERE/'broader_outputs'; OUT.mkdir(exist_ok=True); (OUT/'models').mkdir(exist_ok=True)
START=time.monotonic(); torch.set_num_threads(4)
def save(p,obj): p.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def basis(x,knots):
    z=np.clip(x,-4,4).astype(float); cols=[z[:,j] for j in range(12)]
    for j,values in enumerate(knots): cols.extend(np.maximum(z[:,j]-v,0) for v in values)
    return np.array(cols).T
def learn_knots(x,k): return [np.unique(np.quantile(np.clip(x[:,j],-4,4),np.arange(1,k+1)/(k+1))).tolist() for j in range(12)]
def fit_additive(x,target,knots,alpha,w=None):
    a=basis(x,knots); w=np.ones(len(x)) if w is None else w; w=w/w.sum(); am=np.average(a,axis=0,weights=w); tm=float(np.average(target,weights=w))
    ac=a-am; sd=np.sqrt(np.maximum(np.sum(ac**2*w[:,None],axis=0),1e-20)); z=ac/sd
    coef=np.linalg.solve(z.T@(z*w[:,None])+alpha*np.eye(z.shape[1]),z.T@((target-tm)*w))/sd
    return dict(knots=knots,coefficient=coef.tolist(),intercept=float(tm-am@coef),ridge=alpha,link='clip_probability',input_clip=[-4,4])
def additive_predict(e,x): return np.clip(basis(x,e['knots'])@np.array(e['coefficient'])+e['intercept'],0,1)
def additive_size(e): return 3+12*6+sum(len(k) for k in e['knots'])*10
def evaluate(cid,family,s,teacher,complexity,**extra):
    t=threshold(yv,s); m=metrics(yv,s,t,scores[teacher][1],thresholds[teacher]); gates=dict(fidelity=m['fidelity_r2']>=.9,agreement=m['decision_agreement']>=.95,sensitivity=m['sensitivity']>=.9,sensitivity_loss=m['sensitivity_loss']<=.03,complexity=complexity<=25)
    row=dict(candidate_id=cid,family=family,teacher=teacher,threshold=t,complexity=complexity,qualifies=all(gates.values()),**{f'gate_{k}':v for k,v in gates.items()},**extra,**m)
    np.savez_compressed(OUT/'models'/f'{cid}_validation.npz',probability=s,prediction=(s>=t).astype('int8')); return row
def edge_predict(e,x):
    z=np.clip(x,-4,4).astype(float)
    for i,layer in enumerate(e['layers']):
        coeff=np.array(layer['polynomial']); out=np.broadcast_to(np.array(layer['bias']),(len(z),len(layer['bias']))).copy()
        for power in range(coeff.shape[2]): out+=(z**power)@coeff[:,:,power].T
        out+=(z*expit(z))@np.array(layer['base']).T
        z=np.clip(4*np.tanh(out/4),-4,4) if i==0 else out
    return expit(z[:,0])

if __name__=='__main__':
    inputs=[Path(__file__),HERE/'BROAD_EXTENSION_PROTOCOL.md',P1/'train_arrays.npz',P1/'validation_arrays.npz',REM/'models/kan_h16_g16_s89.pt',HERE/'pilot_outputs/teacher_validation.csv']+[HERE/f'pilot_outputs/{m}_teacher_scores.npz' for m in ('kan','random_forest','mlp')]
    save(OUT/'input_hashes.json',{str(p.relative_to(ROOT)):sha(p) for p in inputs})
    tr=np.load(P1/'train_arrays.npz',allow_pickle=False); va=np.load(P1/'validation_arrays.npz',allow_pickle=False); xt,xv=tr['X'],va['X']; yt,yv=tr['y'],va['y']
    thresholds=pd.read_csv(HERE/'pilot_outputs/teacher_validation.csv').set_index('teacher').threshold.to_dict(); scores={}
    for m in thresholds:
        q=np.load(HERE/f'pilot_outputs/{m}_teacher_scores.npz',allow_pickle=False); scores[m]=(q['train'],q['validation'])
    rows=[]; models={}
    for k in (1,3,7):
        knots=learn_knots(xt,k)
        for alpha in (.001,.1):
            for m in scores:
                e=fit_additive(xt,scores[m][0],knots,alpha); cid=f'{m}_additive_k{k}_a{alpha}'; row=evaluate(cid,'additive',additive_predict(e,xv),m,additive_size(e),requested_knots=k,ridge=alpha); e['validation']=row; save(OUT/'models'/f'{cid}.json',e); models[cid]=e; rows.append(row)
    state=torch.load(REM/'models/kan_h16_g16_s89.pt',map_location='cpu',weights_only=False)['state_dict']; original=KAN().eval(); original.load_state_dict(state)
    assert float(abs(kan_predict(original,xv)-scores['kan'][1]).max())<2e-6
    grid=np.linspace(-4,4,129)
    for degree in (1,2,3):
        layers=[]
        for prefix in ('first','second'):
            spline=state[prefix+'.coeff'].numpy(); coeff=np.empty((*spline.shape[:2],degree+1)); knots=state[prefix+'.knots'].numpy()
            for o in range(spline.shape[0]):
                for j in range(spline.shape[1]): coeff[o,j]=np.polynomial.polynomial.polyfit(grid,np.interp(grid,knots,spline[o,j]),degree)
            layers.append(dict(polynomial=coeff.tolist(),base=state[prefix+'.base'].numpy().tolist(),bias=state[prefix+'.bias'].numpy().tolist()))
        e=dict(layers=layers,degree=degree,grid=grid.tolist(),input_clip=[-4,4]); cid=f'kan_edge_degree{degree}'
        complexity=208*(3*degree+12)+34+191+64+2
        row=evaluate(cid,'edgewise',edge_predict(e,xv),'kan',complexity,polynomial_degree=degree,stored_parameters=sum(np.array(l['polynomial']).size+np.array(l['base']).size+len(l['bias']) for l in layers)); e['validation']=row; save(OUT/'models'/f'{cid}.json',e); models[cid]=e; rows.append(row)
    table=pd.DataFrame(rows); table.to_csv(OUT/'surrogate_validation.csv',index=False)
    selected={}
    for family in ('additive','edgewise'):
        g=table[(table.teacher=='kan')&(table.family==family)].sort_values(['fidelity_r2','complexity','candidate_id'],ascending=[False,True,True]); selected[family]=g.iloc[0].candidate_id
    selected['accepted_candidates']=table.loc[table.qualifies,'candidate_id'].tolist(); selected['diagnostic_only']=True; save(OUT/'selected_references.json',selected)
    # Conditional record-cluster bootstrap; no teacher refitting.
    groups=tr['record_id'].astype(str); unique=np.unique(groups); rng=np.random.default_rng(20261004); stability=[]; probabilities={'polynomial':[],'additive':[]}; coefficients=[]
    fixed=models[selected['additive']]; a=np.clip(xt,-4,4).astype(float); target=scores['kan'][0].astype(float)
    def omp(w):
        am=np.average(a,axis=0,weights=w); tm=np.average(target,weights=w); ac=a-am; gram=ac.T@(ac*w[:,None]); xy=ac.T@((target-tm)*w); norm=np.sqrt(np.maximum(np.diag(gram),1e-30))
        with warnings.catch_warnings():
            warnings.simplefilter('ignore'); c=orthogonal_mp_gram(gram/norm[:,None]/norm[None,:],xy/norm,n_nonzero_coefs=3)/norm
        return float(tm-am@c),c
    base_intercept,base_coef=omp(np.ones(len(a))); base_support=set(np.flatnonzero(abs(base_coef)>1e-12)); baseline=np.clip(np.clip(xv,-4,4)@base_coef+base_intercept,0,1)
    save(OUT/'fixed_polynomial_reference.json',dict(intercept=base_intercept,coefficient=base_coef.tolist(),terms=3,degree=1,complexity=21,link='clip_probability',threshold=threshold(yv,baseline),selection='Fixed before execution'))
    for b in range(30):
        counts=dict(zip(unique,np.bincount(rng.integers(0,len(unique),len(unique)),minlength=len(unique)))); w=np.array([counts[g] for g in groups],dtype=float)
        offset,c=omp(w); support=set(np.flatnonzero(abs(c)>1e-12)); s=np.clip(np.clip(xv,-4,4)@c+offset,0,1); probabilities['polynomial'].append(s); coefficients.append(c)
        bootstrap_ids=np.repeat(np.arange(len(xt)),w.astype(int))
        e=fit_additive(xt,target,learn_knots(xt[bootstrap_ids],fixed['validation']['requested_knots']),fixed['ridge'],w); q=additive_predict(e,xv); probabilities['additive'].append(q); save(OUT/'models'/f'bootstrap_additive_{b:02}.json',e)
        stability.append(dict(replicate=b,unique_training_groups=int((np.array(list(counts.values()))>0).sum()),polynomial_support_jaccard=len(support&base_support)/len(support|base_support),polynomial_r2=float(r2_score(scores['kan'][1],s)),additive_r2=float(r2_score(scores['kan'][1],q)),polynomial_threshold=threshold(yv,s),additive_threshold=threshold(yv,q)))
    pd.DataFrame(stability).to_csv(OUT/'stability_replicates.csv',index=False); co=np.array(coefficients)
    pd.DataFrame(dict(feature=tr['feature_names'].astype(str),inclusion_frequency=(abs(co)>1e-12).mean(axis=0),coefficient_p025=np.quantile(co,.025,axis=0),coefficient_p975=np.quantile(co,.975,axis=0))).to_csv(OUT/'polynomial_feature_stability.csv',index=False)
    np.savez_compressed(OUT/'stability_predictions.npz',polynomial=np.array(probabilities['polynomial']),additive=np.array(probabilities['additive']),polynomial_coefficient=co)
    summary=dict(cpu_seconds=time.monotonic()-START,candidates=len(rows),accepted=int(table.qualifies.sum()),selected_references=selected,bootstrap_replicates=30,training_source_groups=len(unique),mean_support_jaccard=float(np.mean([r['polynomial_support_jaccard'] for r in stability])),mean_probability_sd={m:float(np.std(p,axis=0,ddof=1).mean()) for m,p in probabilities.items()},gpu_used=False)
    save(OUT/'summary.json',summary); save(OUT/'output_hashes.json',{str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='output_hashes.json'}); print(json.dumps(summary,indent=2))
