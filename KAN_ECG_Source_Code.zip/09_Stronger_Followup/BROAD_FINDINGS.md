# Broader experimental findings

Eighteen additive surrogate fits and three direct KAN edgewise simplifications were tested against frozen teachers. Best KAN validation probability R2: additive 0.6488, edgewise 0.5619; all 21 fail joint gates. The best additive KAN expression has 915 counted nodes, not a 25-node compact rule. Higher decision agreement does not repair probability fidelity or sensitivity retention.

Thirty training-source-group bootstrap fits each for a fixed three-term polynomial and a selected additive reference show conditional explanation variability. Mean polynomial support Jaccard 0.5667; post/pre-RR ratio selected in all fits, but other terms vary. Mean across-beat probability SD 0.0632 polynomial, 0.0715 additive. This is not teacher-training stability or causal evidence.

Three exploratory source-group-separated classifier splits merge records 201/202. Fold-specific imputation/scaling use training groups only. Eighteen fits give KAN F1 0.8499/0.7992/0.4545 and RF 0.8310/0.9315/0.2478. Rankings vary; overlapping/reused MIT-BIH observations do not make three independent replications.

New SVDB holdout uses all 78 records, 184,347 eligible beats and 9,937 ventricular beats, with weights, transforms, thresholds and surrogate choices frozen before outcome examination. KAN/RF/MLP F1 0.4256/0.3775/0.4291. Record-cluster paired KAN-minus-RF F1 interval 0.00065 to 0.11752. Every record used lead fallback; source-patient independence/nonoverlap remains unverified.

Rejected additive diagnostic reference: F1 0.6010, probability R2 against KAN 0.5277, sensitivity 0.7773. Explicitly post-hoc, unadjusted paired additive-minus-KAN F1 interval 0.05676 to 0.29322. Better reference-label F1 on this database does not make it a faithful explanation or clinically safe method. No gate relaxed or model retuned. This motivates a separate predictive-distillation question, not a breakthrough claim.

Independent audit verifies 393 output hashes, source labels/record alignment, all new metrics/gates and bootstrap draws. All 18 validation and nine selected test predictions reproduce fitted model files to 3.33e-16 maximum discrepancy. Corrected benchmark random initialization matches original training code. Zero-initialization diagnostic excluded and preserved; unintended duplicate stopped before holdout download. Successful execution times are stage-specific and exclude those preliminary runs and audit/render work. No GPU/Kaggle or paid compute.

Latest paper has 15 IEEE-style main pages. Twenty substantive pages, verified patient-independent confirmation, teacher-training stability and an accepted faithful clinical equation remain unmet. Original study files are preserved. No publication, recognition or award guarantee.
